require 'digest'
require_relative 'ingest'
require_relative 'parser'

module ScriptGuard
  # Independent check that every extracted record points at the exact source text.
  # Re-reads each source from the input (fresh ZIP read / fresh file read), decodes it with the
  # same rules, and compares line + column slices. Also cross-checks structural counts with
  # simple line regexes that do not depend on the parser's state machine.
  class Validator
    def initialize(config)
      @config = config
    end

    def call(ingest_result, episodes, streams)
      fails = []
      checked = Hash.new(0)
      fresh = {}
      ingest_result.sources.each do |src|
        next unless src.key
        bytes = Ingest.reread(ingest_result.input_path, ingest_result.input_kind, src.path, @config)
        checked['source_bytes'] += 1
        fails << "#{src.path}: bytes changed since ingestion" unless Digest::SHA256.hexdigest(bytes) == src.sha256
        lines, = Ingest.decode_bytes(bytes)
        fails << "#{src.path}: decoded lines differ from ingestion" unless lines == src.lines
        fresh[src.key] = lines
      end
      line = ->(key, n) { (fresh[key] || [])[n - 1] }
      key_of = episodes.each_with_object({}) { |e, h| h[[e.number, e.filename]] = e.key }

      episodes.each do |ep|
        src_lines = fresh[ep.key] || []
        # structural counts, independent of the parser state machine
        starts = src_lines.count { |l| l.strip =~ /\AStart:\s*\(/i }
        timed = ep.blocks.count(&:timing)
        checked['count_timing_lines'] += 1
        fails << "#{ep.key}: #{starts} 'Start:' lines but #{timed} timed blocks" unless starts == timed
        scenes = src_lines.count { |l| l.strip =~ /\ASCENE\s+\d+\s*\z/i }
        checked['count_scene_markers'] += 1
        fails << "#{ep.key}: #{scenes} SCENE lines but #{ep.scenes.size} scenes" unless scenes == ep.scenes.size
        labels = src_lines.count { |l| l.strip =~ /\A\*\*.+\*\*\z/ }
        checked['count_block_labels'] += 1
        fails << "#{ep.key}: #{labels} label lines but #{ep.blocks.size} blocks" unless labels == ep.blocks.size
        ep.scenes.each do |s|
          next unless s.heading
          checked['scene_heading'] += 1
          fails << "#{s.id}: heading not found on L#{s.heading.line}" unless line.(ep.key, s.heading.line).to_s.include?(s.heading.raw)
        end
        ep.blocks.each do |b|
          checked['block_label'] += 1
          fails << "#{b.id}: label not on L#{b.label_line}" unless line.(ep.key, b.label_line).to_s.strip == "**#{b.label_raw}**"
          b.body.each do |bl|
            checked['block_body_line'] += 1
            fails << "#{b.id}: body differs on L#{bl.line}" unless line.(ep.key, bl.line) == bl.text
          end
        end
      end

      streams.speaker_labels.each do |m|
        k = key_of[[m.episode, m.filename]]
        checked['speaker_label'] += 1
        fails << "#{m.id}: label mismatch" unless line.(k, m.label_line).to_s.strip == "**#{m.label_raw}**"
        if m.text_line
          checked['speaker_label_text_line'] += 1
          t = line.(k, m.text_line).to_s
          fails << "#{m.id}: text_line L#{m.text_line} is not dialogue text" if t.strip.empty? || t.strip.start_with?('**', 'Start:')
        end
      end
      streams.text_mentions.each do |m|
        k = key_of[[m.episode, m.filename]]
        l = line.(k, m.line).to_s
        checked['text_mention'] += 1
        fails << "#{m.id}: '#{m.surface}' not at L#{m.line} C#{m.col_start}" unless l[m.col_start...m.col_end] == m.surface && l == m.original_text
      end
      streams.location_mentions.each do |m|
        k = key_of[[m.episode, m.filename]]
        checked['location_mention'] += 1
        fails << "#{m.id}: '#{m.segment}' not at L#{m.line} C#{m.col_start}" unless line.(k, m.line).to_s[m.col_start...m.col_end] == m.segment
      end
      { 'passed' => fails.empty?, 'checks' => checked, 'failure_count' => fails.size, 'failures' => fails.first(200) }
    end
  end
end
