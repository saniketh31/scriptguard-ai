require 'json'
require 'csv'
require 'time'
require 'fileutils'

module ScriptGuard
  module Detect
    # Writes findings.json, findings.csv, report.md and entity_inventory.csv.
    class Report
      LABELS = {
        'strong_same_entity_candidate' => ['Check first', 'The scripts themselves link these forms to one character or place.'],
        'possible_spelling_variant' => ['Worth checking', 'Spellings are close, but no line in the scripts links them. They may or may not be the same.'],
        'unresolved' => ['Needs your judgement', 'The evidence points both ways or is too thin to call.'],
        'likely_intentional_variation' => ['Probably intentional', 'Looks like a deliberate choice, such as a title or a description used before a name is revealed.'],
        'likely_different_entities' => ['Checked: probably different', 'These look alike but the scripts show they are different. Listed so you can confirm.']
      }.freeze
      CATEGORY = { 'NAME_VARIANT' => 'Name variation', 'SPELLING' => 'Possible spelling error', 'SPEAKER_LABEL_ALIAS' => 'Same character, different speaker labels',
                   'TITLE_VARIANT' => 'Title variation in speaker labels', 'LOCATION_VARIANT' => 'Place-name variation' }.freeze
      KIND = { 'dialogue' => 'dialogue', 'action' => 'action', 'camera' => 'camera direction', 'sfx' => 'sound cue', 'heading' => 'scene heading',
               'logline' => 'logline', 'continuity' => 'continuity note', 'speaker_label' => 'speaker label' }.freeze

      def initialize(corpus, findings, stats, out_dir)
        @c, @f, @s, @out = corpus, findings, stats, out_dir
      end

      def write
        FileUtils.mkdir_p(@out)
        meta = { 'tool' => "ScriptGuard #{VERSION}", 'generated_at' => Time.now.utc.iso8601, 'input' => @c.input_name,
                 'input_fingerprint' => @c.manifest['input']['fingerprint_after'], 'episodes' => @c.episode_order.size,
                 'verifier' => 'none (deterministic rules only)',
                 'source_files' => @c.manifest['sources'].map { |s| { 'path' => s['path'], 'sha256' => s['sha256'], 'key' => s['key'] } },
                 'confidentiality' => 'Contains screenplay excerpts. Do not publish.' }
        File.write(path('findings.json'), JSON.pretty_generate('run' => meta, 'summary' => @s, 'findings' => @f) + "\n")
        write_csv
        write_inventory
        File.write(path('report.md'), markdown(meta))
        %w[findings.json findings.csv report.md entity_inventory.csv]
      end

      private

      def path(n)
        File.join(@out, n)
      end

      def forms_cell(f)
        f['candidate_names'].map { |n| "#{n['form']} (#{n['count']}×; ep #{span(n['episodes'])})" }.join(' | ')
      end

      def span(eps)
        return '-' if eps.nil? || eps.empty?
        runs = eps.sort.slice_when { |a, b| b != a + 1 }.map { |r| r.size > 1 ? "#{r.first}–#{r.last}" : r.first.to_s }
        runs.join(', ')
      end

      def write_csv
        CSV.open(path('findings.csv'), 'w') do |csv|
          csv << %w[issue_id review_status category assessment confidence_level severity entity_type candidate_names episodes
                    line_references suggested_canonical explanation suggested_action reviewer_note canonical_form fingerprint]
          @f.each do |f|
            csv << [f['issue_id'], f['review_status'], f['category'], f['assessment'], f['confidence_level'], f['severity'], f['entity_type'],
                    forms_cell(f), span(f['episode_references']), f['line_references'].first(12).join(' '),
                    f['suggested_canonical'] && f['suggested_canonical']['form'], f['explanation'], f['suggested_action'], '', '', f['fingerprint']]
          end
        end
      end

      def write_inventory
        rows = []
        @c.labels.group_by { |l| l['speaker'] }.each do |label, recs|
          rows << ['speaker_label', label, recs.size, span(recs.map { |r| r['episode'] }.uniq), "ep#{recs.first['episode']}:L#{recs.first['label_line']}", recs.size, 'speaker_label']
        end
        @c.mentions.group_by { |m| m['name'] }.each do |name, ms|
          ms = ms.sort_by { |m| [m['episode'], m['line']] }
          rows << ['text_name', name, ms.size, span(ms.map { |m| m['episode'] }.uniq), "ep#{ms.first['episode']}:L#{ms.first['line']}",
                   ms.count { |m| m['source_kind'] == 'dialogue' }, ms.first['name_evidence']]
        end
        @c.locations.group_by { |l| l['segment'] }.each do |seg, ls|
          rows << ['heading_location', seg, ls.size, span(ls.map { |l| l['episode'] }.uniq), "ep#{ls.first['episode']}:L#{ls.first['line']}", 0, ls.first['name_evidence']]
        end
        order = { 'speaker_label' => 0, 'text_name' => 1, 'heading_location' => 2 }
        ev = { 'speaker_label' => 0, 'proper_noun' => 0, 'proper_noun_in_text' => 0 }
        rows.sort_by! { |r| [order[r[0]], ev.fetch(r[6], 1), -r[2], r[1]] }
        CSV.open(path('entity_inventory.csv'), 'w') do |csv|
          csv << %w[stream form occurrences episodes first_seen in_dialogue name_evidence]
          rows.each { |r| csv << r }
        end
      end

      # ---------------- Markdown for a script editor ----------------
      def markdown(meta)
        by = @f.group_by { |f| f['assessment'] }
        out = []
        out << "# ScriptGuard report: #{meta['input']}"
        out << ''
        out << "_Generated #{meta['generated_at']} · #{meta['episodes']} episodes · deterministic rules only (no AI model) · **contains script excerpts: do not share outside the team**._"
        out << ''
        out << '## At a glance'
        out << ''
        out << '| Section | Findings | What it means |'
        out << '|---|---:|---|'
        Detector::SECTION_ORDER.each_with_index do |a, i|
          out << "| #{i + 1}. #{LABELS[a][0]} | #{(by[a] || []).size} | #{LABELS[a][1]} |"
        end
        out << ''
        out << "Every quoted line below was re-checked against the original script files (#{@s['evidence_verified']} lines checked)."
        out << ''
        out << '**How to use this:** work through sections 1–3. For each finding, decide in `findings.csv` (column `review_status`): ' \
               '`confirmed_error`, `confirmed_alias`, `intentional_variation`, `different_entities` or `unresolved`. The tool never edits the scripts. ' \
               '_Confidence_ = how sure the tool is that the forms mean the same person or place. _Importance_ = how much it matters if they do.'
        out << ''
        Detector::SECTION_ORDER.each_with_index do |a, i|
          list = by[a] || []
          next if list.empty?
          out << "## #{i + 1}. #{LABELS[a][0]} (#{list.size})"
          out << ''
          out << "_#{LABELS[a][1]}_"
          out << ''
          if %w[likely_intentional_variation likely_different_entities].include?(a)
            out << '| ID | Type | Forms | Why |'
            out << '|---|---|---|---|'
            list.each { |f| out << "| #{f['issue_id']} | #{CATEGORY[f['category']]} | #{forms_cell(f)} | #{esc(f['explanation'])} |" }
            out << ''
          else
            list.each { |f| out.concat(block(f)) }
          end
        end
        out << '---'
        out << "Rules: G1 similar spellings · G2 rare form next to a frequent one · G3 title-only label difference · G4 explicit link between a descriptive label and a name · " \
               'G5 when the label is used relative to the name reveal · B1–B3 supporting evidence · N1–N2 contradicting evidence. Details: `findings.json`.'
        out.join("\n") + "\n"
      end

      def block(f)
        o = []
        o << "### #{f['issue_id']} · #{CATEGORY[f['category']]} · importance: #{f['severity']} · confidence: #{f['confidence_level']}"
        o << ''
        o << '| Form | Times | Episodes | First seen | In dialogue |'
        o << '|---|---:|---|---|---:|'
        f['candidate_names'].each do |n|
          o << "| **#{n['form']}** | #{n['count']} | #{span(n['episodes'])} | #{n['first_seen'] || '-'} | #{n['in_dialogue'] || '-'} |"
        end
        o << ''
        o << "**Why flagged:** #{f['explanation']}"
        o << ''
        o << '**Evidence:**'
        f['evidence'].first(8).each do |e|
          o << "- Ep #{e['episode']}, line #{e['line']} (#{KIND[e['source_kind']] || e['source_kind']}#{e['speaker_label'] && e['source_kind'] != 'speaker_label' ? ", #{e['speaker_label']}" : ''}): #{quote(e)}"
        end
        o << "- … #{f['evidence'].size - 8} more in findings.json" if f['evidence'].size > 8
        o << ''
        sc = f['suggested_canonical']
        o << "**Suggested action:** #{f['suggested_action']}#{sc ? " (most frequent form: _#{sc['form']}_)" : ''}"
        o << ''
        o
      end

      def quote(e)
        raw = e['original_text'].to_s
        if e['source_kind'] == 'speaker_label'
          spoken = e['spoken_text'].to_s.strip
          return "`#{raw.strip}` → #{trim(spoken, 90)}"
        end
        a = [e['col_start'] - 60, 0].max
        b = [e['col_end'] + 60, raw.size].min
        pre = (a > 0 ? '…' : '') + raw[a...e['col_start']]
        post = raw[e['col_end']...b] + (b < raw.size ? '…' : '')
        "#{esc(pre.lstrip)}**#{esc(e['matched_span'])}**#{esc(post.rstrip)}"
      end

      def trim(s, n)
        s.size > n ? s[0, n - 1] + '…' : s
      end

      def esc(s)
        s.to_s.gsub('|', '\|').gsub('*', '\*').gsub('_', '\_')
      end
    end
  end
end
