require 'digest'
require 'set'
require_relative 'text'
require_relative 'candidates'

module ScriptGuard
  module Detect
    # Turns candidates + context signals into assessed, evidence-backed findings (spec §4, §5E, §6).
    #
    # Assessment (tool, before review)      confidence_level = how sure the forms denote ONE entity
    #   strong_same_entity_candidate  -> high       (explicit textual bridge B1/B2/B3, no contradiction)
    #   possible_spelling_variant     -> medium/low (string evidence only)
    #   likely_intentional_variation  -> high       (title-only label difference; descriptor used before the name is revealed)
    #   unresolved                    -> low        (conflicting or insufficient evidence)
    #   likely_different_entities     -> low        (N1/N2 contradiction; "rejected by contextual checks")
    # severity = how much it would matter if real (independent axis, see #severity).
    #
    # Grouping is CONSTRAINED: G1 edges are joined strongest-first, and a join is refused if any member of
    # one side has an N1/N2 contradiction with any member of the other. Spelling never overrides contradiction.
    class Detector
      SECTION_ORDER = %w[strong_same_entity_candidate possible_spelling_variant unresolved likely_intentional_variation likely_different_entities].freeze
      SEV_ORDER = { 'high' => 0, 'medium' => 1, 'low' => 2 }.freeze

      attr_reader :stats

      def initialize(corpus)
        @c = corpus
        @d = corpus.config['detection']
        @evidence_checked = 0
      end

      def call
        cand = Candidates.new(@c).call
        @forms = cand.forms
        @info = cand.label_info
        raw = []
        clusters, blocked = constrained_clusters(cand)
        g2_by_pair = cand.g2_pairs.select { |p| p[:kind] == 'token' }.map { |p| [Text.pair(p[:rare], p[:frequent]), p] }.to_h
        used_g2 = Set.new
        clusters.each do |members, edges|
          g2_here = g2_by_pair.select { |pr, _| members.include?(pr[0]) && members.include?(pr[1]) }
          g2_here.each_key { |k| used_g2 << k }
          raw << cluster_finding(members, edges, g2_here.values, cand)
        end
        blocked.each { |e| raw << blocked_finding(e, cand) }
        g2_by_pair.each do |pr, p|
          next if used_g2.include?(pr) || blocked.any? { |e| Text.pair(e[:a], e[:b]) == pr }
          raw << spelling_finding(p, cand)
        end
        cand.g2_pairs.select { |p| p[:kind] == 'label' }.each { |p| raw << label_spelling_finding(p) }
        cand.g3_pairs.each { |p| raw << title_finding(p) }
        cand.g4_pairs.each { |p| raw << alias_finding(p) }
        findings = raw.compact
        findings.each { |f| finalize(f) }
        findings.sort_by! do |f|
          [SECTION_ORDER.index(f['assessment']), SEV_ORDER[f['severity']], -f['candidate_names'].sum { |n| n['count'] }, f['category']]
        end
        findings.each_with_index { |f, i| f['issue_id'] = format('SG-%03d', i + 1) }
        @stats = cand.counts.merge(
          'clusters_from_G1' => clusters.size, 'G1_joins_refused_by_context' => blocked.size,
          'findings_total' => findings.size,
          'findings_by_assessment' => tally(findings.map { |f| f['assessment'] }),
          'findings_by_category' => tally(findings.map { |f| f['category'] }),
          'findings_by_severity' => tally(findings.map { |f| f['severity'] }),
          'rejected_by_context' => findings.count { |f| f['assessment'] == 'likely_different_entities' },
          'evidence_items' => findings.sum { |f| f['evidence'].size }, 'evidence_verified' => @evidence_checked,
          'name_filter' => cand.filter_report
        )
        findings
      end

      private

      def tally(a)
        a.each_with_object(Hash.new(0)) { |x, h| h[x] += 1 }
      end

      # ---------- grouping -------------------------------------------------------------------------
      def constrained_clusters(cand)
        cannot = {}
        cand.n2.each { |pr, ev| cannot[pr] = { rule: 'N2', evidence: ev } }
        cand.n1.each { |pr, ev| cannot[pr] ||= { rule: 'N1', evidence: ev } }
        parent = {}
        members = Hash.new { |h, k| h[k] = Set[k] }
        find = lambda do |x|
          parent[x] ||= x
          parent[x] == x ? x : (parent[x] = find.call(parent[x]))
        end
        accepted = []
        blocked = []
        cand.g1_edges.sort_by { |e| [-e[:sim], e[:a], e[:b]] }.each do |e|
          ra = find.call(e[:a])
          rb = find.call(e[:b])
          next if ra == rb
          conflict = nil
          members[ra].each do |x|
            members[rb].each do |y|
              conflict ||= cannot[Text.pair(x, y)] && [x, y, cannot[Text.pair(x, y)]]
            end
          end
          if conflict
            blocked << e.merge(conflict: conflict)
          else
            parent[rb] = ra
            members[ra] |= members[rb]
            accepted << e
          end
        end
        roots = accepted.flat_map { |e| [e[:a], e[:b]] }.uniq.group_by { |x| find.call(x) }
        clusters = roots.values.map do |ms|
          set = Set.new(ms)
          [ms.sort, accepted.select { |e| set.include?(e[:a]) && set.include?(e[:b]) }]
        end
        # report each refused join once per form pair
        [clusters, blocked.uniq { |e| Text.pair(e[:conflict][0], e[:conflict][1]) }]
      end

      # ---------- finding builders ----------------------------------------------------------------
      def entity_type(folds)
        u = folds.each_with_object(Hash.new(0)) { |f, h| @forms[f][:usage].each { |k, v| h[k] += v } }
        person = u['person'] + u['surname']
        place = u['place']
        if place > 0 && (person > 0 || u['house'] > 0) then 'family_or_house'
        elsif place > 0 then 'place'
        else 'person'
        end
      end

      def names_for(folds)
        folds.map do |f|
          fm = @forms[f]
          first = fm[:occs].first
          { 'form' => fm[:spellings].first, 'spellings' => fm[:spellings], 'normalised' => f, 'count' => fm[:count],
            'episodes' => fm[:episodes], 'in_dialogue' => fm[:in_dialogue],
            'first_seen' => "ep#{first[:episode]}:L#{first[:line]}", 'name_evidence' => name_evidence(fm) }
        end.sort_by { |n| [-n['count'], n['form']] }
      end

      def name_evidence(fm)
        return 'proper_noun' if fm[:proper]
        return 'capitalised_only_at_sentence_start' if fm[:initial_only]
        fm[:in_text] ? 'common_word' : 'heading_only'
      end

      def cluster_finding(members, edges, g2s, cand)
        b3 = members.combination(2).map { |a, b| [Text.pair(a, b), cand.b3[Text.pair(a, b)]] }.select { |_, v| v }
        et = entity_type(members)
        category = et == 'place' ? 'LOCATION_VARIANT' : 'NAME_VARIANT'
        category = 'SPELLING' if members.size == 2 && !g2s.empty?
        assessment, conf = if !b3.empty? then ['strong_same_entity_candidate', 'high']
                           elsif members.size == 2 && !g2s.empty? && g2s.first[:rare] && @forms[g2s.first[:rare]][:initial_only] then ['unresolved', 'low']
                           else ['possible_spelling_variant', edges.map { |e| e[:sim] }.max >= 0.8 ? 'medium' : 'low']
                           end
        ev = []
        b3.first(2).each { |_, (oa, ob)| ev << occ_evidence(oa, 'co_reference') << occ_evidence(ob, 'co_reference') }
        ev.concat(interleave(members.sort_by { |f| -@forms[f][:count] }.map { |f| form_evidence(f) }))
        joins = edges.map { |e| "#{display(e[:a])}–#{display(e[:b])} (similarity #{e[:sim]})" }
        expl = []
        expl << "#{members.size} spellings share the first #{@d['g1_prefix_letters']} letters and are close in spelling (rule G1): #{joins.join('; ')}."
        expl << "One form is rare and close to a frequent one (rule G2)." unless g2s.empty?
        b3.each { |(a, b), (oa, ob)| expl << "B3: \"#{display(a)}\" and \"#{display(b)}\" both name the same kind of place (#{oa[:head].downcase}) in the same scene (ep#{oa[:episode]} L#{oa[:line]} and L#{ob[:line]})." }
        expl << 'No sentence in the scripts links these forms explicitly; the grouping rests on spelling only.' if b3.empty?
        weak = edges.select { |e| e[:sim] < 0.65 }
        expl << "Weak link(s), check these members first: #{weak.map { |e| "#{display(e[:a])}–#{display(e[:b])}" }.join(', ')}." unless weak.empty?
        { 'category' => category, 'entity_type' => et, 'folds' => members, 'candidate_names' => names_for(members),
          'assessment' => assessment, 'confidence_level' => conf, 'evidence' => ev,
          'signals' => { 'generators' => (['G1'] + (g2s.empty? ? [] : ['G2'])), 'bridges' => b3.empty? ? [] : ['B3'],
                         'contradictions' => [], 'links' => edges.map { |e| [display(e[:a]), display(e[:b]), e[:sim]] }, 'verifier' => 'none' },
          'explanation' => expl.join(' ') }
      end

      def blocked_finding(e, cand)
        x, y, conf = e[:conflict]
        a, b = e[:a], e[:b]
        et = entity_type([a, b])
        ev = []
        if conf[:rule] == 'N2'
          oa, ob = conf[:evidence]
          ev << occ_evidence(oa, 'contradiction') << occ_evidence(ob, 'contradiction')
          why = "N2: \"#{display(x)}\" and \"#{display(y)}\" are named separately in the same line (ep#{oa[:episode]} L#{oa[:line]}), which suggests two different #{et == 'person' ? 'people' : 'entities'}."
        else
          labels = conf[:evidence][:labels]
          ev.concat(labels.flat_map { |l| label_evidence(l, 1, conf[:evidence][:scenes].first) })
          why = "N1: speaker labels #{labels.join(' and ')} both speak in the same scene, so they are different characters."
        end
        ev.concat(interleave([form_evidence(a, 2), form_evidence(b, 2)]))
        link = x == a && y == b || x == b && y == a ? '' : " (the conflict is between \"#{display(x)}\" and \"#{display(y)}\", already grouped with these forms)"
        { 'category' => et == 'place' ? 'LOCATION_VARIANT' : 'NAME_VARIANT', 'entity_type' => et, 'folds' => [a, b],
          'candidate_names' => names_for([a, b]), 'assessment' => 'likely_different_entities', 'confidence_level' => 'low',
          'evidence' => ev,
          'signals' => { 'generators' => ['G1'], 'bridges' => [], 'contradictions' => [conf[:rule]], 'verifier' => 'none' },
          'explanation' => "\"#{display(a)}\" and \"#{display(b)}\" look alike (rule G1, similarity #{e[:sim]}), but were not grouped. #{why}#{link}" }
      end

      def spelling_finding(p, cand)
        r, f = p[:rare], p[:frequent]
        pr = Text.pair(r, f)
        rare = @forms[r]
        if (conf = cand.n2[pr] || cand.n1[pr])
          rule = cand.n2[pr] ? 'N2' : 'N1'
          return { 'category' => 'SPELLING', 'entity_type' => 'person', 'folds' => [r, f], 'candidate_names' => names_for([r, f]),
                   'assessment' => 'likely_different_entities', 'confidence_level' => 'low',
                   'evidence' => form_evidence(r) + form_evidence(f, 1),
                   'signals' => { 'generators' => ['G2'], 'bridges' => [], 'contradictions' => [rule], 'verifier' => 'none' },
                   'explanation' => "Rare form \"#{display(r)}\" is close to \"#{display(f)}\" (rule G2), but #{rule} indicates different entities." }
        end
        initial = rare[:initial_only]
        { 'category' => 'SPELLING', 'entity_type' => entity_type([f]), 'folds' => [r, f], 'candidate_names' => names_for([r, f]),
          'assessment' => initial ? 'unresolved' : 'possible_spelling_variant',
          'confidence_level' => initial ? 'low' : 'medium', 'evidence' => form_evidence(r) + form_evidence(f, 2),
          'signals' => { 'generators' => ['G2'], 'bridges' => [], 'contradictions' => [], 'verifier' => 'none' },
          'explanation' => "\"#{display(r)}\" appears #{rare[:count]} time(s); \"#{display(f)}\" appears #{@forms[f][:count]} times and differs by #{p[:distance]} letter(s) (rule G2)." +
            (initial ? " \"#{display(r)}\" only ever appears at the start of a sentence or line, so it may be a different name, a nickname or a cover name rather than a typo." : '') }
      end

      def label_spelling_finding(p)
        { 'category' => 'SPELLING', 'entity_type' => 'person', 'folds' => [], 'labels' => [p[:rare], p[:frequent]],
          'candidate_names' => label_names([p[:rare], p[:frequent]]), 'assessment' => 'possible_spelling_variant', 'confidence_level' => 'medium',
          'evidence' => label_evidence(p[:rare], 2) + label_evidence(p[:frequent], 1),
          'signals' => { 'generators' => ['G2'], 'bridges' => [], 'contradictions' => [], 'verifier' => 'none' },
          'explanation' => "Speaker label #{p[:rare]} is rare and #{p[:distance]} letter(s) away from the frequent label #{p[:frequent]} (rule G2)." }
      end

      def title_finding(p)
        labels = [p[:titled], p[:bare]]
        if p[:co_speak].empty?
          assess, conf = 'likely_intentional_variation', 'high'
          expl = "#{p[:titled]} and #{p[:bare]} differ only by a title (rule G3) and never speak in the same scene."
          expl += p[:shared_episodes].empty? ? ' They are never used in the same episode, which looks like a per-episode labelling choice.' : " Both labels are used within episode(s) #{p[:shared_episodes].join(', ')}."
          contra = []
        else
          assess, conf = 'likely_different_entities', 'low'
          expl = "#{p[:titled]} and #{p[:bare]} differ only by a title (rule G3), but both speak in the same scene (N1), so they are probably different characters."
          contra = ['N1']
        end
        { 'category' => 'TITLE_VARIANT', 'entity_type' => 'person', 'folds' => [], 'labels' => labels,
          'candidate_names' => label_names(labels), 'assessment' => assess, 'confidence_level' => conf,
          'evidence' => label_evidence(p[:titled], 2) + label_evidence(p[:bare], 2),
          'signals' => { 'generators' => ['G3'], 'bridges' => [], 'contradictions' => contra, 'verifier' => 'none', 'shared_episodes' => p[:shared_episodes] },
          'explanation' => expl }
      end

      def alias_finding(p)
        rules = p[:bridges].map { |b| b[:rule] }.uniq.sort
        tgt = p[:target_is_label] ? p[:target] : p[:target].sub('text:', '')
        labels = p[:target_is_label] ? [p[:label], p[:target]] : [p[:label]]
        names = label_names(labels)
        names << { 'form' => tgt, 'spellings' => [tgt], 'normalised' => Text.fold(tgt), 'count' => p[:bridges].size, 'episodes' => p[:bridges].map { |b| b[:mention]['episode'] }.uniq.sort, 'first_seen' => nil, 'name_evidence' => 'text_name' } unless p[:target_is_label]
        assess, conf, contra = if !p[:co_speak].empty? then ['unresolved', 'low', ['N1']]
                               elsif p[:post_reveal_episodes].empty? then ['likely_intentional_variation', 'high', []]
                               else ['strong_same_entity_candidate', 'high', []]
                               end
        ev = p[:bridges].first(5).map { |b| mention_evidence(b[:mention], 'bridge') }
        ev.concat(label_evidence(p[:label], 2))
        ev.concat(label_evidence(p[:target], 1)) if p[:target_is_label]
        expl = []
        p[:bridges].group_by { |b| b[:rule] }.each do |rule, bs|
          expl << "#{rule}: #{bs.size} line(s) where #{bs.first[:how]} (\"#{bs.first[:name]}\")."
        end
        expl << "G5 timeline: #{p[:label]} speaks in episode(s) #{p[:label_episodes].join(', ')}"
        expl[-1] += p[:target_is_label] ? "; #{p[:target]} in #{p[:target_episodes].join(', ')}." : '.'
        expl << "The name first appears in episode #{p[:reveal_episode]}; label uses before that (#{p[:pre_reveal_episodes].join(', ')}) look like an intentional description before the reveal." unless p[:pre_reveal_episodes].empty?
        expl << "The label is still used after the name is known, in episode(s) #{p[:post_reveal_episodes].join(', ')}." unless p[:post_reveal_episodes].empty?
        expl << "But both labels speak in the same scene (N1: #{p[:co_speak].size} scene(s)), which contradicts the bridge." unless p[:co_speak].empty?
        { 'category' => 'SPEAKER_LABEL_ALIAS', 'entity_type' => 'person', 'folds' => [], 'labels' => labels,
          'candidate_names' => names, 'assessment' => assess, 'confidence_level' => conf, 'evidence' => ev,
          'signals' => { 'generators' => %w[G4 G5], 'bridges' => rules, 'contradictions' => contra, 'verifier' => 'none',
                         'reveal_episode' => p[:reveal_episode], 'pre_reveal_episodes' => p[:pre_reveal_episodes],
                         'post_reveal_episodes' => p[:post_reveal_episodes] },
          'explanation' => expl.join(' ') }
      end

      def label_names(labels)
        labels.map do |l|
          i = @info[l]
          b = i[:blocks].first
          { 'form' => l, 'spellings' => [l], 'normalised' => Text.fold(l), 'count' => i[:blocks].size, 'episodes' => i[:episodes],
            'in_dialogue' => i[:blocks].size, 'first_seen' => "ep#{b['episode']}:L#{b['label_line']}", 'name_evidence' => 'speaker_label' }
        end
      end

      def display(fold)
        @forms[fold] ? @forms[fold][:spellings].first : fold
      end

      # round-robin so every form gets evidence before any form gets a second example
      def interleave(lists)
        out = []
        (0...(lists.map(&:size).max || 0)).each { |i| lists.each { |l| out << l[i] if l[i] } }
        out
      end

      # ---------- evidence -------------------------------------------------------------------------
      # Picks varied occurrences: first, first in dialogue, one per later episode, last.
      def form_evidence(fold, n = @d['evidence_per_form'])
        occs = @forms[fold][:occs]
        picks = [occs.first, occs.find { |o| o[:source_kind] == 'dialogue' }]
        occs.group_by { |o| o[:episode] }.each_value { |l| picks << l.first }
        picks << occs.last
        picks.compact.uniq { |o| [o[:key], o[:line], o[:col_start]] }.first(n).map { |o| occ_evidence(o, 'form_occurrence') }
      end

      def occ_evidence(o, role)
        { 'role' => role, 'form' => o[:form], 'key' => o[:key], 'episode' => o[:episode], 'filename' => o[:filename], 'line' => o[:line],
          'col_start' => o[:col_start], 'col_end' => o[:col_end], 'source_kind' => o[:source_kind], 'speaker_label' => o[:speaker] }
      end

      def mention_evidence(m, role)
        { 'role' => role, 'form' => m['surface'], 'key' => @c.key(m), 'episode' => m['episode'], 'filename' => m['filename'],
          'line' => m['line'], 'col_start' => m['col_start'], 'col_end' => m['col_end'], 'source_kind' => m['source_kind'],
          'speaker_label' => m['speaker'] }
      end

      def label_evidence(label, n, scene = nil)
        blocks = @info[label][:blocks]
        blocks = blocks.select { |b| [@c.key(b), b['scene_number']] == scene } if scene
        picks = blocks.group_by { |b| b['episode'] }.values.map(&:first)
        picks.first(n).map do |b|
          key = @c.key(b)
          raw = @c.line(key, b['label_line']).to_s
          col = raw.index(b['label_raw']) || 0
          { 'role' => 'label_use', 'form' => label, 'key' => key, 'episode' => b['episode'], 'filename' => b['filename'],
            'line' => b['label_line'], 'col_start' => col, 'col_end' => col + b['label_raw'].size, 'source_kind' => 'speaker_label',
            'speaker_label' => label, 'spoken_line' => b['text_line'] }
        end
      end

      # Fills original_text/context from the FRESH source and verifies the span; raises on any mismatch.
      def finalize(f)
        width = @d['context_lines']
        f['evidence'] = f['evidence'].uniq { |e| [e['key'], e['line'], e['col_start']] }.first(@d['evidence_max'])
        f['evidence'].each_with_index do |e, i|
          raw = @c.line(e['key'], e['line'])
          span = raw && raw[e['col_start']...e['col_end']]
          expected = e['source_kind'] == 'speaker_label' ? @info[e['form']][:blocks].map { |b| b['label_raw'] } : [e['form']]
          unless span && (expected.include?(span) || Text.fold(span) == Text.fold(e['form']))
            raise Error, "evidence check failed: #{e['filename']} L#{e['line']} cols #{e['col_start']}-#{e['col_end']} expected #{e['form'].inspect}, found #{span.inspect}"
          end
          @evidence_checked += 1
          before, after = @c.context(e['key'], e['line'], width)
          e['evidence_id'] = "E#{i + 1}"
          e['original_text'] = raw
          e['matched_span'] = span
          e['context_before'] = before
          e['context_after'] = after
          e['spoken_text'] = @c.line(e['key'], e['spoken_line']) if e['spoken_line']
          e['verified'] = true
        end
        f['episode_references'] = f['evidence'].map { |e| e['episode'] }.uniq.sort | f['candidate_names'].flat_map { |n| n['episodes'] }.uniq.sort
        f['episode_references'].sort!
        f['line_references'] = f['evidence'].map { |e| "ep#{e['episode']}:L#{e['line']}" }.uniq
        f['severity'] = severity(f)
        f['suggested_canonical'] = suggestion(f)
        f['suggested_action'] = action(f)
        f['review_status'] = 'pending'
        f['review'] = { 'decision' => nil, 'canonical_form' => nil, 'note' => nil, 'reviewer' => nil, 'decided_at' => nil }
        f['fingerprint'] = 'sha1:' + Digest::SHA1.hexdigest([f['category'], f['candidate_names'].map { |n| n['normalised'] }.sort].to_json)
        f.delete('folds')
      end

      # high: a main-cast/main-house name (>=10 uses, >=3 episodes) has a minority form (>=2 uses) spoken in dialogue
      # medium: any minority form in dialogue, speaker-label splits, or a group spanning >=2 episodes
      # low: title variants, single-occurrence wording, and anything assessed as different/intentional
      def severity(f)
        return 'low' if %w[likely_different_entities likely_intentional_variation].include?(f['assessment'])
        return 'low' if f['category'] == 'TITLE_VARIANT'
        return 'medium' if f['category'] == 'SPEAKER_LABEL_ALIAS'
        names = f['candidate_names']
        total = names.sum { |n| n['count'] }
        eps = names.flat_map { |n| n['episodes'] }.uniq
        minority = names.drop(1)
        if total >= 10 && eps.size >= 3 && minority.any? { |n| n['count'] >= 2 && n['in_dialogue'].to_i > 0 }
          'high'
        elsif minority.any? { |n| n['in_dialogue'].to_i > 0 } || eps.size >= 2
          'medium'
        else
          'low'
        end
      end

      def suggestion(f)
        return nil if f['assessment'] == 'likely_different_entities'
        top = f['candidate_names'].max_by { |n| [n['count'], -(n['episodes'].first || 0)] }
        { 'form' => top['form'], 'basis' => 'most frequent form; tie → earliest', 'is_suggestion' => true }
      end

      def action(f)
        case f['assessment']
        when 'strong_same_entity_candidate'
          f['category'] == 'SPEAKER_LABEL_ALIAS' ? 'Confirm these labels are one character; if so, pick one speaker label (or approve the alias) so voice and face references stay consistent.' :
            'Confirm the canonical spelling in the show bible; mark the other forms as errors or approved aliases.'
        when 'possible_spelling_variant'
          'Check whether these refer to the same person/place. If yes, choose the canonical form; if not, mark as different.'
        when 'unresolved'
          'Needs a story decision: the scripts do not show whether these are the same. Check with the writer or the show bible.'
        when 'likely_intentional_variation'
          'No action unless your style guide requires one label per character.'
        else
          'No action expected; shown so you can confirm the tool kept them apart correctly.'
        end
      end
    end
  end
end
