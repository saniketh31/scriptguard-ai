require 'set'
require_relative 'text'

module ScriptGuard
  module Detect
    # Candidate generation (spec §5D, rules G1–G5) and context features (spec §5E, B1–B3, N1–N2).
    # Produces raw candidates + signals; Detector turns them into assessed findings.
    #
    # Interpretations of the spec, made explicit:
    # * "Name token" = a core token of a stream-B mention (titles/descriptors excluded) or a non-generic
    #   heading token. G1 eligibility = capitalised mid-sentence somewhere AND never lower case.
    # * Plurals ("Vellacourts") are folded onto the singular when the singular exists (not a variant).
    # * B3 (same-scene co-reference) is applied to PLACE usage only and requires the same head noun
    #   ("X Manor" / "Y Manor") in the same scene on different lines. Two person names in one scene is the
    #   normal shape of two different people, so it is never used as positive evidence for persons.
    # * N2 (different referents) = both forms named in separate mentions on the same line. N2 from a
    #   reviewer registry arrives with the registry (Session 4).
    # * G3 = adding/removing a title or article on a speaker label ("LADY MARA"/"MARA"); two different
    #   titles ("LORD X"/"LADY X") are not a title variant. Labels made only of role nouns are excluded.
    # * G5 never emits on its own; it adds a timeline to G4 bridges.
    class Candidates
      Result = Struct.new(:forms, :g1_edges, :g2_pairs, :g3_pairs, :g4_pairs, :n1, :n2, :b3, :counts,
                          :label_info, :filter_report, keyword_init: true)

      def initialize(corpus)
        @c = corpus
        cfg = corpus.config
        @d = cfg['detection']
        @titles = Set.new(cfg['titles'].map(&:upcase))
        @articles = Set.new(@d['articles'].map(&:upcase))
        @descriptors = Set.new(cfg['descriptor_nouns'].map(&:upcase))
        @generic = Set.new(cfg['generic_location_words'].map(&:upcase))
        @self_id = Regexp.new("(?:#{@d['self_identification_patterns'].join('|')})\\z", Regexp::IGNORECASE)
      end

      def call
        counts = Hash.new(0)
        label_info = build_label_info
        forms = build_forms(label_info)
        g1 = g1_edges(forms)
        g2 = g2_pairs(forms) + g2_label_pairs(label_info)
        nodes = Set.new(g1.flat_map { |e| [e[:a], e[:b]] } + g2.select { |p| p[:kind] == 'token' }.flat_map { |p| [p[:rare], p[:frequent]] })
        n2 = n2_same_line(forms, nodes)
        n1 = n1_co_speakers(forms, nodes, label_info)
        b3 = b3_same_scene_place(forms, nodes)
        g3 = g3_title_pairs(label_info)
        g4 = g4_bridges(label_info, forms)
        counts['G1_eligible_tokens'] = forms.count { |_, f| f[:g1_eligible] }
        counts['G1_edges'] = g1.size
        counts['G2_pairs'] = g2.size
        counts['G3_pairs'] = g3.size
        counts['G4_bridge_instances'] = g4.sum { |p| p[:bridges].size }
        counts['G4_pairs'] = g4.size
        counts['G5_timelines'] = g4.size
        counts['B1_bridges'] = g4.sum { |p| p[:bridges].count { |b| b[:rule] == 'B1' } }
        counts['B2_self_identifications'] = g4.sum { |p| p[:bridges].count { |b| b[:rule] == 'B2' } }
        counts['B3_pairs'] = b3.size
        counts['N1_pairs'] = n1.size
        counts['N2_pairs'] = n2.size
        Result.new(forms: forms, g1_edges: g1, g2_pairs: g2, g3_pairs: g3, g4_pairs: g4, n1: n1, n2: n2, b3: b3,
                   counts: counts, label_info: label_info, filter_report: filter_report(forms))
      end

      private

      # ---------- labels -------------------------------------------------------------------------
      def build_label_info
        info = {}
        @c.labels.group_by { |l| l['speaker'] }.each do |label, recs|
          words = label.split(/\s+/)
          prefix = words.take_while { |w| @titles.include?(w.upcase) || @articles.include?(w.upcase) }
          core = words.drop(prefix.size)
          name_tokens = core.reject { |w| @descriptors.include?(w.upcase) }
          info[label] = { label: label, words: words, prefix: prefix, core: core, blocks: recs,
                          episodes: recs.map { |r| r['episode'] }.uniq.sort,
                          core_fold: Text.fold(core.join(' ')),
                          role_only: core.empty? || core.all? { |w| @descriptors.include?(w.upcase) } }
          info[label][:named] = !core.empty? && name_tokens.size == core.size &&
                                core.all? { |w| eligible_fold?(Text.fold(w)) || initial_only_fold?(Text.fold(w)) }
        end
        info
      end

      def stat(fold)
        @c.stats[fold]
      end

      def eligible_fold?(fold)
        s = stat(fold)
        s && s['cap_mid'] > 0 && s['lower'].zero?
      end

      def initial_only_fold?(fold)
        s = stat(fold)
        s && s['cap_mid'].zero? && s['lower'].zero?
      end

      # ---------- name-token occurrences -----------------------------------------------------------
      def build_forms(label_info)
        label_cores = Set.new(label_info.values.select { |i| i[:core].size == 1 }.map { |i| i[:core_fold] })
        occs = []
        @c.mentions.each do |m|
          next if m['name_evidence'] == 'common_word' && m['core_tokens'].all? { |t| !eligible_fold?(Text.fold(t)) && !initial_only_fold?(Text.fold(t)) }
          tokens = m['tokens']
          core = m['core_tokens']
          pos = 0
          key = @c.key(m)
          tokens.each_with_index do |t, i|
            idx = m['name'].index(t, pos) || pos
            pos = idx + t.size
            next unless core.include?(t)
            fold = Text.fold(t)
            nxt = tokens[i + 1]
            usage, head = if nxt && @generic.include?(nxt.upcase) then ['place', nxt.upcase]
                          elsif i > 0 && tokens[i - 1].casecmp('of').zero? then ['house', nil]
                          elsif i > 0 && core.include?(tokens[i - 1]) then ['surname', nil]
                          elsif label_cores.include?(fold) || !m['titles'].empty? then ['person', nil]
                          else ['unknown', nil]
                          end
            occs << { fold: fold, form: t, key: key, episode: m['episode'], filename: m['filename'], line: m['line'],
                      col_start: m['col_start'] + idx, col_end: m['col_start'] + idx + t.size, source_kind: m['source_kind'],
                      speaker: m['speaker'], scene: m['scene_number'], usage: usage, head: head, mention_id: m['id'],
                      initial: m['sentence_initial'] && i.zero? }
          end
        end
        @c.locations.each do |l|
          key = @c.key(l)
          pos = 0
          l['tokens'].each_with_index do |t, i|
            idx = l['segment'].index(t, pos) || pos
            pos = idx + t.size
            next unless l['non_generic_tokens'].include?(t)
            nxt = l['tokens'][i + 1]
            occs << { fold: Text.fold(t), form: t, key: key, episode: l['episode'], filename: l['filename'], line: l['line'],
                      col_start: l['col_start'] + idx, col_end: l['col_start'] + idx + t.size, source_kind: 'heading',
                      speaker: nil, scene: l['scene_number'], usage: 'place', head: nxt && @generic.include?(nxt.upcase) ? nxt.upcase : nil,
                      mention_id: l['id'], initial: false }
          end
        end
        folds = Set.new(occs.map { |o| o[:fold] })
        canon = lambda do |f|
          f.size >= 5 && f.end_with?('s') && folds.include?(f[0..-2]) ? f[0..-2] : f
        end
        forms = {}
        occs.group_by { |o| canon.call(o[:fold]) }.each do |fold, list|
          list.sort_by! { |o| [o[:episode], o[:line], o[:col_start]] }
          s = stat(fold)
          forms[fold] = { fold: fold, occs: list, count: list.size, episodes: list.map { |o| o[:episode] }.uniq.sort,
                          spellings: list.map { |o| o[:form] }.uniq, plural_of: list.any? { |o| o[:fold] != fold },
                          usage: list.each_with_object(Hash.new(0)) { |o, h| h[o[:usage]] += 1 },
                          in_dialogue: list.count { |o| o[:source_kind] == 'dialogue' },
                          g1_eligible: fold.size >= @d['g1_min_length'] && eligible_fold?(fold),
                          proper: eligible_fold?(fold), initial_only: initial_only_fold?(fold),
                          never_lower: s ? s['lower'].zero? : true, in_text: !s.nil? }
        end
        forms
      end

      # ---------- G1: token family -------------------------------------------------------------------
      def g1_edges(forms)
        nodes = forms.values.select { |f| f[:g1_eligible] }.map { |f| f[:fold] }.sort
        k = @d['g1_prefix_letters']
        edges = []
        nodes.group_by { |f| f[0, k] }.each_value do |group|
          group.combination(2).each do |a, b|
            sim = Text.similarity(a, b)
            edges << { a: a, b: b, sim: sim.round(3) } if sim >= @d['g1_min_similarity']
          end
        end
        edges
      end

      # ---------- G2: rare near frequent ----------------------------------------------------------------
      def g2_pairs(forms)
        frequent = forms.values.select { |f| f[:proper] && f[:count] >= @d['g2_frequent_min'] }
        rare = forms.values.select { |f| f[:count] <= @d['g2_rare_max'] && f[:in_text] && f[:never_lower] }
        pairs = []
        rare.each do |r|
          frequent.each do |f|
            next if r[:fold] == f[:fold] || r[:fold][0] != f[:fold][0]
            d = Text.levenshtein(r[:fold], f[:fold])
            pairs << { kind: 'token', rare: r[:fold], frequent: f[:fold], distance: d } if d <= @d['g2_max_distance']
          end
        end
        pairs
      end

      def g2_label_pairs(info)
        frequent = info.values.select { |i| i[:blocks].size >= @d['g2_frequent_min'] }
        rare = info.values.select { |i| i[:blocks].size <= @d['g2_rare_max'] }
        pairs = []
        rare.each do |r|
          frequent.each do |f|
            next if r[:label] == f[:label] || r[:label][0] != f[:label][0]
            next if r[:core_fold] == f[:core_fold] # title variants belong to G3
            d = Text.levenshtein(Text.fold(r[:label]), Text.fold(f[:label]))
            pairs << { kind: 'label', rare: r[:label], frequent: f[:label], distance: d } if d <= @d['g2_max_distance']
          end
        end
        pairs
      end

      # ---------- G3: title-only difference on speaker labels ----------------------------------------
      def g3_title_pairs(info)
        out = []
        info.values.combination(2).each do |x, y|
          next if x[:role_only] || y[:role_only] || x[:core_fold] != y[:core_fold]
          titled, bare = x[:prefix].empty? ? [y, x] : [x, y]
          next unless bare[:prefix].empty? && !titled[:prefix].empty?
          same_ep = titled[:episodes] & bare[:episodes]
          out << { titled: titled[:label], bare: bare[:label], shared_episodes: same_ep,
                   co_speak: @c.scenes_where_both_speak(titled[:label], bare[:label]) }
        end
        out
      end

      # ---------- G4: speaker-label bridges (B1 explicit, B2 self-identification) + G5 timeline -------
      def g4_bridges(info, forms)
        named = info.values.select { |i| i[:named] }
        descriptor_labels = info.values.reject { |i| i[:named] || i[:words].all? { |w| @titles.include?(w.upcase) } }
        by_line = @c.mentions.group_by { |m| [@c.key(m), m['line']] }
        folds_of = @c.mentions.map { |m| [m['id'], m['tokens'].map { |t| Text.fold(t) }] }.to_h
        pairs = Hash.new { |h, k| h[k] = [] }
        descriptor_labels.each do |li|
          words = li[:words].drop_while { |w| @articles.include?(w.upcase) }
          next if words.empty?
          wf = words.map { |w| Text.fold(w) }
          phrase = /(?<![\p{L}])#{words.map { |w| Regexp.escape(w) }.join('\s+')}(?![\p{L}])/i
          first_word = wf.first
          @c.mentions.each do |m|
            mf = folds_of[m['id']]
            # B2: self-identification in dialogue spoken under this label
            if m['source_kind'] == 'dialogue' && m['speaker'] == li[:label] && @self_id.match?(m['original_text'][0, m['col_start']])
              add_bridge(pairs, li, m['core_tokens'], m, 'B2', 'speaker names themself', named)
            end
          end
          # B1b apposition: "<Name>, the <Label words>," / "the <Label words>, <Name>,"
          # Not an apposition when the phrase continues as a list (", and" / ", or") or when the label
          # is not introduced by "the" (e.g. "a weary guard, Tobias, ..." describes, not names).
          by_line.each do |(_key, _ln), ms|
            text = ms.first['original_text']
            next unless text.downcase.include?(first_word)
            md = phrase.match(text)
            next unless md
            pos = [md.begin(0), md.end(0)]
            # B1a: "<Label words> <Name>": the name directly follows the label phrase. Located in the raw
            # line, so it works even when the extractor split the phrase at a sentence start.
            k = pos[1] + text[pos[1]..-1][/\A[ \t]+/].to_s.size
            # ...and the phrase must start the capitalised run: "Rider" inside "Hooded Rider Tobin"
            # is the tail of a longer descriptor, not a label RIDER.
            starts_run = text[0...pos[0]] !~ /\p{Lu}[\p{L}'’-]*\s+\z/
            if k > pos[1] && starts_run
              host = ms.find { |m| m['col_start'] <= k && k < m['col_end'] }
              if host
                tail = text[k...host['col_end']].sub(/['’]s\z/i, '')
                add_bridge(pairs, li, tail.split(/\s+/), host, 'B1', 'descriptor followed by name in one phrase', named)
              end
            end
            ms.each do |m|
              next if m['core_tokens'].empty? || folds_of[m['id']].each_cons(wf.size).include?(wf)
              name_first = m['col_end'] <= pos[0] && text[m['col_end']...pos[0]] =~ /\A\s*,\s*the\s+\z/i &&
                           text[pos[1]..-1] !~ /\A[^.!?;]*,\s*(and|or)\s/i
              label_first = m['col_start'] >= pos[1] && text[0...pos[0]] =~ /\bthe\s+\z/i &&
                            text[pos[1]...m['col_start']] =~ /\A\s*,\s*\z/ && text[m['col_end']..-1] !~ /\A\s*,?\s*(and|or)\s/i
              if name_first || label_first
                add_bridge(pairs, li, m['core_tokens'], m, 'B1', 'name and descriptor in apposition', named)
              end
            end
          end
        end
        pairs.map do |(label, target), bridges|
          timeline(info, label, target, bridges, forms)
        end
      end

      def add_bridge(pairs, li, name_tokens, m, rule, how, named)
        folds = name_tokens.map { |t| Text.fold(t) }
        return if folds.empty?
        # the "name" must contain a real name token: not only titles/role nouns ("Guard Captain")
        name_like = folds.reject { |f| @titles.include?(f.upcase) || @descriptors.include?(f.upcase) }
        return if name_like.empty? || name_like.none? { |f| eligible_fold?(f) }
        target = named.select { |n| (n[:core].map { |w| Text.fold(w) } - folds).empty? }
                      .max_by { |n| n[:blocks].size }
        tgt = target ? target[:label] : "text:#{name_tokens.join(' ')}"
        return if tgt == li[:label]
        pairs[[li[:label], tgt]] << { rule: rule, how: how, mention: m, name: name_tokens.join(' ') }
      end

      def timeline(info, label, target, bridges, forms)
        li = info[label]
        tgt_label = target.start_with?('text:') ? nil : info[target]
        name_folds = tgt_label ? tgt_label[:core].map { |w| Text.fold(w) } : target.sub('text:', '').split.map { |w| Text.fold(w) }
        first_text = name_folds.map { |f| forms[f] && forms[f][:episodes].first }.compact.min
        first_label = tgt_label && tgt_label[:episodes].first
        reveal = [first_text, first_label].compact.min
        pre = reveal ? li[:episodes].select { |e| e < reveal } : []
        post = li[:episodes] - pre
        co = tgt_label ? @c.scenes_where_both_speak(label, target) : []
        { label: label, target: target, target_is_label: !tgt_label.nil?, bridges: bridges, label_episodes: li[:episodes],
          target_episodes: tgt_label ? tgt_label[:episodes] : [], reveal_episode: reveal, pre_reveal_episodes: pre,
          post_reveal_episodes: post, co_speak: co }
      end

      # ---------- context: N2 same line, N1 co-speakers, B3 same-scene place ---------------------------
      def n2_same_line(forms, nodes)
        res = {}
        idx = Hash.new { |h, k| h[k] = [] }
        nodes.each { |f| forms[f][:occs].each { |o| idx[[o[:key], o[:line]]] << [f, o] if o[:source_kind] != 'heading' } }
        idx.each_value do |list|
          list.combination(2).each do |(fa, oa), (fb, ob)|
            next if fa == fb || oa[:mention_id] == ob[:mention_id]
            res[Text.pair(fa, fb)] ||= [oa, ob]
          end
        end
        res
      end

      def n1_co_speakers(forms, nodes, info)
        by_fold = Hash.new { |h, k| h[k] = [] }
        info.each_value { |i| by_fold[i[:core_fold]] << i[:label] if i[:core].size == 1 && nodes.include?(i[:core_fold]) }
        res = {}
        by_fold.keys.combination(2).each do |a, b|
          by_fold[a].product(by_fold[b]).each do |la, lb|
            scenes = @c.scenes_where_both_speak(la, lb)
            res[Text.pair(a, b)] = { labels: [la, lb], scenes: scenes } unless scenes.empty?
          end
        end
        res
      end

      def b3_same_scene_place(forms, nodes)
        res = {}
        idx = Hash.new { |h, k| h[k] = [] }
        nodes.each { |f| forms[f][:occs].each { |o| idx[[o[:key], o[:scene], o[:head]]] << [f, o] if o[:usage] == 'place' && o[:head] && o[:scene] } }
        idx.each_value do |list|
          list.combination(2).each do |(fa, oa), (fb, ob)|
            next if fa == fb || oa[:line] == ob[:line]
            res[Text.pair(fa, fb)] ||= [oa, ob]
          end
        end
        res
      end

      # How many name tokens a strict "mid-sentence only" filter would exclude (spec concern).
      def filter_report(forms)
        initial_only = forms.values.select { |f| f[:initial_only] }
        { 'tokens_total' => forms.size, 'g1_eligible' => forms.values.count { |f| f[:g1_eligible] },
          'proper_noun' => forms.values.count { |f| f[:proper] }, 'initial_only' => initial_only.size,
          'initial_only_examples' => initial_only.sort_by { |f| -f[:count] }.first(15).map { |f| "#{f[:spellings].first} (#{f[:count]})" } }
      end
    end
  end
end
