require 'json'
require 'set'
require_relative '../ingest'
require_relative '../pipeline'

module ScriptGuard
  module Detect
    # Read-only view of a Session-2 parse run (manifest + streams) plus fresh source lines.
    # Fresh lines are re-read from the ORIGINAL input and are the only basis for evidence text,
    # so a report can never quote something the source does not contain.
    class Corpus
      attr_reader :manifest, :episodes, :labels, :mentions, :locations, :stats, :config, :input_name

      def self.load(run_dir, config)
        rd = ->(f) { File.join(run_dir, f) }
        %w[manifest.json episodes.json speaker_labels.jsonl text_mentions.jsonl location_mentions.jsonl token_stats.json].each do |f|
          raise Error, "parse output missing: #{rd.(f)} (run `scriptguard parse` first)" unless File.file?(rd.(f))
        end
        jl = ->(f) { File.readlines(rd.(f)).map { |l| JSON.parse(l) } }
        new(JSON.parse(File.read(rd.('manifest.json'))), JSON.parse(File.read(rd.('episodes.json'))),
            jl.('speaker_labels.jsonl'), jl.('text_mentions.jsonl'), jl.('location_mentions.jsonl'),
            JSON.parse(File.read(rd.('token_stats.json'))), config)
      end

      def initialize(manifest, episodes, labels, mentions, locations, stats, config)
        @manifest, @episodes, @labels, @mentions, @locations, @stats, @config = manifest, episodes, labels, mentions, locations, stats, config
        input = manifest['input']['path']
        @input_name = File.basename(input)
        raise Error, "original input not found: #{input}" unless File.exist?(input)
        now = Pipeline.fingerprint(input)
        unless now == manifest['input']['fingerprint_after']
          raise Error, 'the input has changed since it was parsed (fingerprint differs); run `scriptguard parse` again'
        end
        @lines = {}
        @key_of = {}
        manifest['sources'].each do |s|
          next unless s['key']
          bytes = Ingest.reread(input, manifest['input']['kind'], s['path'], config)
          raise Error, "source changed since parse: #{s['path']}" unless Digest::SHA256.hexdigest(bytes) == s['sha256']
          @lines[s['key']] = Ingest.decode_bytes(bytes)[0]
          @key_of[[s['episode_number'], s['filename']]] = s['key']
        end
        index_scenes
      end

      def key(rec)
        @key_of.fetch([rec['episode'], rec['filename']])
      end

      def line(key, n)
        (@lines[key] || [])[n - 1]
      end

      def context(key, n, width)
        lines = @lines[key] || []
        before = ([n - width, 1].max...n).map { |i| lines[i - 1] }
        after = ((n + 1)..[n + width, lines.size].min).map { |i| lines[i - 1] }
        [before, after]
      end

      # scene number containing a physical line (nil for header lines)
      def scene_of(key, n)
        starts = @scene_starts[key] || []
        hit = starts.select { |line, _| line <= n }.last
        hit && hit[1]
      end

      # set of speaker labels that speak in [key, scene]
      def speakers_in(key, scene)
        @speakers[[key, scene]] || Set.new
      end

      def scenes_where_both_speak(a, b)
        @speakers.select { |_, s| s.include?(a) && s.include?(b) }.keys
      end

      def label_blocks(label)
        @label_blocks[label] || []
      end

      def episode_order
        @episodes.map { |e| e['number'] }.uniq.sort
      end

      private

      def index_scenes
        @scene_starts = {}
        @episodes.each do |e|
          @scene_starts[e['key']] = e['scenes'].map { |s| [s['line'], s['number']] }.sort
        end
        @speakers = Hash.new { |h, k| h[k] = Set.new }
        @label_blocks = Hash.new { |h, k| h[k] = [] }
        @labels.each do |l|
          k = key(l)
          @speakers[[k, l['scene_number']]] << l['speaker']
          @label_blocks[l['speaker']] << l
        end
      end
    end
  end
end
