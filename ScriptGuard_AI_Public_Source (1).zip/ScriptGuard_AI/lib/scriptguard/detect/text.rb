module ScriptGuard
  module Detect
    # String helpers. Normalisation builds comparison keys only; original text is never changed.
    module Text
      module_function

      def fold(s)
        s.to_s.downcase.tr('’', "'").gsub(/\s+/, ' ').strip
      end

      def levenshtein(a, b)
        return b.size if a.empty?
        return a.size if b.empty?
        prev = (0..b.size).to_a
        a.each_char.with_index(1) do |ca, i|
          cur = [i]
          b.each_char.with_index(1) do |cb, j|
            cur << [prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca == cb ? 0 : 1)].min
          end
          prev = cur
        end
        prev[b.size]
      end

      def similarity(a, b)
        1.0 - levenshtein(a, b).to_f / [a.size, b.size].max
      end

      def pair(a, b)
        a <= b ? [a, b] : [b, a]
      end

      # Word positions of `words` inside `text` (case-insensitive, whole words). Returns [start, end] or nil.
      def find_phrase(text, words, from = 0)
        re = /(?<![\p{L}])#{words.map { |w| Regexp.escape(w) }.join('\s+')}(?![\p{L}])/i
        m = re.match(text, from)
        m && [m.begin(0), m.end(0)]
      end
    end
  end
end
