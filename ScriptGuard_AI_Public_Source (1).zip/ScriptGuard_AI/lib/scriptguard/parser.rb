require_relative 'model'

module ScriptGuard
  # Parses the screenplay format found in the input pack (see 11_mvp_technical_spec.md §2):
  #
  #   EPISODE NUMBER: / EPISODE LOGLINE: / CONTINUITY NOTES:      (header, any case)
  #   --- SCRIPT START ---
  #   SCENE 01
  #   Scene heading: INT. PLACE – DAY      (field names may be upper case)
  #   Scene start: 00:00.00 / Scene end: 02:18.00
  #   Actions and dialogue:
  #   **LABEL (Manner) (More):**           block label; LABEL is a speaker unless configured as non-dialogue
  #   Start: (00:13.50) | End: (00:14.30)  timing, directly after the label
  #   text line(s)                         body, until a blank line or the next structural line
  #
  # Derived from problem3_research/scripts/parse.rb, extended to keep label AND text line numbers,
  # multi-line bodies, every parenthetical, and warnings for anything unrecognised.
  class Parser
    TS = /\A\s*(\d{1,3}):(\d{2}(?:\.\d+)?)\s*\z/
    LABEL = /\A\*\*(.+?)\*\*\s*\z/
    TIMING = /\AStart:\s*\(([^)]*)\)\s*\|\s*End:\s*\(([^)]*)\)\s*\z/i
    SCENE = /\ASCENE\s+(\d+)\s*\z/i
    FIELD = /\A(Scene heading|Scene start|Scene end):\s*(.*)\z/i
    HEADER = /\A(EPISODE NUMBER|EPISODE LOGLINE|CONTINUITY NOTES):\s*(.*)\z/i
    MARKERS = [/\A-{2,}\s*SCRIPT (START|END)\s*-{2,}\z/i, /\AActions and dialogue:\s*\z/i]

    def initialize(config)
      @non_dialogue = config['non_dialogue_labels'].map(&:upcase)
      @tod = config['time_of_day_words'].map(&:upcase).sort_by { |w| -w.size }
    end

    def self.seconds(raw)
      m = raw.to_s.match(TS)
      m && (m[1].to_i * 60 + m[2].to_f).round(3)
    end

    # Returns [Episode, issues]
    def parse(src)
      issues = []
      warn = lambda do |code, msg, line, sev = 'warning'|
        issues << Issue.new(severity: sev, code: code, message: msg, file: src.path, episode: src.episode_number, line: line)
      end
      ep = Episode.new(key: src.key, number: src.episode_number, filename: src.filename, path: src.path,
                       header_episode_number: src.header_episode_number, scenes: [], blocks: [],
                       line_count: src.lines.size, duplicate: src.duplicate)
      lines = src.lines
      scene = nil
      i = 0
      while i < lines.size
        raw = lines[i]
        l = raw.strip
        n = i + 1
        if l.empty? || MARKERS.any? { |re| re.match?(l) }
          i += 1
          next
        end
        if (m = l.match(HEADER))
          field = m[1].upcase
          if field == 'EPISODE LOGLINE' then ep.logline = Header.new(text: m[2], line: n)
          elsif field == 'CONTINUITY NOTES' then ep.continuity = Header.new(text: m[2], line: n)
          end
        elsif (m = l.match(SCENE))
          scene = Scene.new(id: format('%s-s%02d', ep.key, m[1].to_i), number: m[1].to_i, line: n,
                            block_ids: [], field_case: nil)
          warn.call('duplicate_scene_number', "scene #{m[1].to_i} appears more than once", n) if ep.scenes.any? { |s| s.number == scene.number }
          ep.scenes << scene
        elsif (m = l.match(FIELD))
          if scene.nil?
            warn.call('field_outside_scene', "#{m[1]} before any SCENE marker", n)
          else
            set_field(scene, m[1], m[2], raw, n, warn)
          end
        elsif (m = l.match(LABEL))
          i = parse_block(ep, scene, lines, i, m[1], warn)
          next
        elsif l.match?(TIMING)
          warn.call('orphan_timing', 'timing line without a preceding block label', n)
        else
          warn.call('unrecognised_line', "not part of any block: #{l[0, 80].inspect}", n)
        end
        i += 1
      end
      finish(ep, warn)
      [ep, issues]
    end

    private

    def set_field(scene, name, value, raw, n, warn)
      kind = name.downcase
      case_style = name == name.upcase ? 'upper' : 'normal'
      scene.field_case = scene.field_case.nil? || scene.field_case == case_style ? case_style : 'mixed'
      case kind
      when 'scene heading'
        warn.call('duplicate_scene_field', 'second scene heading in one scene', n) if scene.heading
        scene.heading = parse_heading(value, raw, n)
      when 'scene start', 'scene end'
        t = Timing.new(start_raw: value, start_s: self.class.seconds(value), line: n)
        warn.call('unparsable_time', "#{name}: #{value.inspect}", n) unless t.start_s
        kind == 'scene start' ? scene.start = t : scene.end = t
      end
    end

    # Splits "INT. VELLACOURT HALL - GREAT HALL – NIGHT" into prefix, location part (with column) and time of day.
    def parse_heading(value, raw, n)
      col = raw.index(value) || 0
      loc = value.dup
      loc_col = col
      int_ext = nil
      if (m = loc.match(%r{\A(INT\.?\s*/\s*EXT\.?|EXT\.?\s*/\s*INT\.?|I/E\.?|INT\.|EXT\.|INT\b|EXT\b)\s*}i))
        int_ext = m[1].upcase.delete(' ')
        loc_col += m[0].size
        loc = loc[m[0].size..-1]
      end
      tod = nil
      seps = []
      loc.scan(/\s+[-–—]\s+/) { seps << Regexp.last_match }
      if (last = seps.last)
        cand = loc[last.end(0)..-1].strip.upcase
        if @tod.include?(cand)
          tod = cand
          loc = loc[0, last.begin(0)]
        end
      end
      Heading.new(raw: value, line: n, int_ext: int_ext, location_raw: loc.rstrip, location_col: loc_col, time_of_day: tod)
    end

    def parse_block(ep, scene, lines, i, inner, warn)
      n = i + 1
      label = inner.strip.sub(/:\s*\z/, '').strip
      parens = []
      speaker = label.dup
      while (m = speaker.match(/\s*\(([^()]*)\)\s*\z/))
        parens.unshift(m[1].strip)
        speaker = speaker[0, m.begin(0)]
      end
      speaker = speaker.strip
      warn.call('ambiguous_label', "label still contains parentheses after parsing: #{label.inspect}", n) if speaker.include?('(') || speaker.include?(')')
      warn.call('empty_label', 'block label is empty', n) if speaker.empty?
      kind = @non_dialogue.include?(speaker.upcase) ? speaker.upcase : 'DIALOGUE'
      if kind != 'DIALOGUE' && !parens.empty?
        warn.call('non_dialogue_with_parenthetical', "#{label.inspect} treated as #{kind}", n, 'info')
      end
      if kind == 'DIALOGUE' && speaker != speaker.upcase
        warn.call('mixed_case_speaker', "speaker label is not upper case: #{speaker.inspect}", n, 'info')
      end
      j = i + 1
      timing = nil
      if j < lines.size && (m = lines[j].strip.match(TIMING))
        timing = Timing.new(start_raw: m[1], end_raw: m[2], start_s: self.class.seconds(m[1]), end_s: self.class.seconds(m[2]), line: j + 1)
        warn.call('unparsable_time', "block timing #{m[1].inspect} / #{m[2].inspect}", j + 1) unless timing.start_s && timing.end_s
        j += 1
      else
        warn.call('missing_timing', "block #{speaker.inspect} has no Start/End line", n)
      end
      body = []
      while j < lines.size
        t = lines[j].strip
        break if t.empty? || structural?(t)
        body << BodyLine.new(line: j + 1, text: lines[j])
        j += 1
      end
      warn.call('empty_block', "block #{speaker.inspect} has no text", n) if body.empty?
      warn.call('block_outside_scene', "block #{speaker.inspect} appears before any SCENE marker", n) if scene.nil?
      id = format('%s-b%04d', ep.key, ep.blocks.size + 1)
      ep.blocks << Block.new(id: id, episode: ep.number, scene_number: scene && scene.number, kind: kind,
                             label_raw: inner, label_line: n, speaker: kind == 'DIALOGUE' ? speaker : nil,
                             parentheticals: parens, timing: timing, body: body,
                             text_line: body.first && body.first.line)
      scene.block_ids << id if scene
      j
    end

    def structural?(t)
      LABEL.match?(t) || SCENE.match?(t) || FIELD.match?(t) || HEADER.match?(t) || TIMING.match?(t)
    end

    def finish(ep, warn)
      warn.call('no_scenes', 'no SCENE markers found', nil, 'error') if ep.scenes.empty?
      warn.call('no_blocks', 'no labelled blocks found', nil, 'error') if ep.blocks.empty?
      warn.call('missing_header', 'no EPISODE LOGLINE line', nil, 'info') unless ep.logline
      ep.scenes.each do |s|
        warn.call('scene_without_heading', "scene #{s.number} has no heading", s.line) unless s.heading
        warn.call('scene_without_timing', "scene #{s.number} lacks start or end time", s.line) unless s.start && s.end
      end
      ep.status = if ep.scenes.empty? || ep.blocks.empty? then 'failed'
                  else 'parsed'
                  end
    end
  end
end
