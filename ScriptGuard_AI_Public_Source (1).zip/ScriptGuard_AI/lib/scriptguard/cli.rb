require 'optparse'
require_relative 'pipeline'

module ScriptGuard
  # Command line: scriptguard parse INPUT --out DIR [--expect 1-50] [--config FILE]
  class CLI
    USAGE = <<~TXT
      ScriptGuard #{VERSION} - cross-episode name and speaker-label consistency checker

      Usage:
        scriptguard scan   INPUT --out DIR [--expect FIRST-LAST] [--config FILE] [--quiet]   parse + detect + reports
        scriptguard parse  INPUT --out DIR [--expect FIRST-LAST] [--config FILE] [--quiet]   parse + extract only
        scriptguard detect --run DIR [--out DIR] [--config FILE] [--quiet]                   detect on an existing parse run

        INPUT   a .zip archive or a folder of episode .txt files (never modified)
        --out   output folder (must not be inside the input folder)
        Reports: findings.json, findings.csv (review_status column), report.md, entity_inventory.csv

      Exit codes: 0 ok · 1 input problems reported (missing/duplicate/unreadable) · 2 validation failed or fatal error
    TXT

    def self.start(argv, out: $stdout, err: $stderr)
      cmd = argv.shift
      unless %w[parse scan detect].include?(cmd)
        (cmd.nil? || %w[-h --help help].include?(cmd) ? out : err).puts USAGE
        return cmd.nil? || %w[-h --help help].include?(cmd) ? 0 : 2
      end
      opts = { quiet: false }
      parser = OptionParser.new do |o|
        o.on('--out DIR') { |v| opts[:out] = v }
        o.on('--run DIR') { |v| opts[:run] = v }
        o.on('--expect RANGE', /\A\d+-\d+\z/) { |v| a, b = v.split('-').map(&:to_i); opts[:expect] = (a..b) }
        o.on('--config FILE') { |v| opts[:config] = v }
        o.on('--quiet') { opts[:quiet] = true }
        o.on('-h', '--help') { out.puts USAGE; return 0 }
      end
      rest = parser.parse(argv)
      config = Pipeline.load_config(opts[:config])
      if cmd == 'detect'
        if opts[:run].nil?
          err.puts USAGE
          return 2
        end
        res = Detect.run(opts[:run], config, out_dir: opts[:out])
        print_detection(res, out) unless opts[:quiet]
        return 0
      end
      input = rest.first
      if input.nil? || opts[:out].nil?
        err.puts USAGE
        return 2
      end
      run = Pipeline.new(config).run(input, out_dir: opts[:out], expect: opts[:expect])
      print_summary(run, out) unless opts[:quiet]
      return run.exit_code if cmd == 'parse' || run.exit_code == 2

      res = Detect.run(opts[:out], config)
      print_detection(res, out) unless opts[:quiet]
      run.exit_code
    rescue ScriptGuard::Error, OptionParser::ParseError => e
      err.puts "error: #{e.message}"
      2
    end

    def self.print_detection(res, out)
      s = res.stats
      a = s['findings_by_assessment']
      out.puts "Detection    #{s['findings_total']} findings: strong #{a['strong_same_entity_candidate']}, possible #{a['possible_spelling_variant']}, " \
               "unresolved #{a['unresolved']}, intentional #{a['likely_intentional_variation']}, rejected by context #{a['likely_different_entities']}"
      out.puts "             by category: #{s['findings_by_category'].map { |k, v| "#{k} #{v}" }.join(', ')}"
      out.puts "             by severity: #{s['findings_by_severity'].map { |k, v| "#{k} #{v}" }.join(', ')}"
      out.puts "Rules        G1 edges #{s['G1_edges']} (#{s['G1_joins_refused_by_context']} joins refused), G2 #{s['G2_pairs']}, G3 #{s['G3_pairs']}, " \
               "G4 #{s['G4_pairs']} pairs / #{s['G4_bridge_instances']} bridges; B1 #{s['B1_bridges']}, B2 #{s['B2_self_identifications']}, " \
               "B3 #{s['B3_pairs']}; N1 #{s['N1_pairs']}, N2 #{s['N2_pairs']}"
      out.puts "Evidence     #{s['evidence_verified']} of #{s['evidence_items']} evidence lines verified against the original files"
      out.puts "Reports      #{res.files.map { |f| File.join(res.out_dir, f) }.join("\n             ")}"
    end

    def self.print_summary(run, out)
      s = run.summary
      ep = s['episodes']
      out.puts "ScriptGuard #{VERSION} — parse"
      out.puts "Input        #{s['input']['path']} (#{s['input']['kind']}), unchanged: #{s['input']['unchanged'] ? 'yes' : 'NO'}"
      out.puts "Files        read #{s['files']['read']}, skipped system #{s['files']['skipped_system_files']}, unsupported #{s['files']['unsupported']}, unsafe archive entries #{s['files']['unsafe_archive_entries']}"
      out.puts "Episodes     discovered #{ep['discovered']}, expected range #{ep['expected_range'] || '-'}, unidentified #{ep['unidentified']}"
      out.puts "             status #{ep['status'].map { |k, v| "#{k}=#{v}" }.join(', ')}"
      out.puts "             missing #{ep['missing'].empty? ? 'none' : ep['missing'].join(', ')}; duplicates #{ep['duplicates'].empty? ? 'none' : ep['duplicates'].join(', ')}"
      out.puts "Structure    scenes #{s['structure']['scenes']}, blocks #{s['structure']['blocks']} (#{s['structure']['blocks_by_kind'].map { |k, v| "#{k} #{v}" }.join(', ')})"
      a = s['stream_a_speaker_labels']
      out.puts "Stream A     speaker-label mentions #{a['mentions']}, distinct labels #{a['distinct_labels']}"
      b = s['stream_b_text_mentions']
      out.puts "Stream B     text mentions #{b['mentions']}, distinct names #{b['distinct_names']}"
      out.puts "             by evidence: #{b['by_name_evidence'].map { |k, v| "#{k} #{v}" }.join(', ')}"
      c = s['stream_c_location_mentions']
      out.puts "Stream C     location mentions #{c['mentions']}, distinct segments #{c['distinct_segments']}"
      out.puts "             by evidence: #{c['by_name_evidence'].map { |k, v| "#{k} #{v}" }.join(', ')}"
      i = s['issues']
      out.puts "Issues       errors #{i['errors']}, warnings #{i['warnings']}, info #{i['info']}#{i['by_code'].empty? ? '' : ' — ' + i['by_code'].map { |k, v| "#{k} #{v}" }.join(', ')}"
      run.issues.select { |x| x.severity == 'error' }.first(10).each do |x|
        out.puts "  ERROR #{x.code}: #{x.message}#{x.file ? " [#{x.file}#{x.line ? " L#{x.line}" : ''}]" : ''}"
      end
      v = s['validation']
      out.puts "Validation   #{v['passed'] ? 'PASSED' : 'FAILED'} (#{v['checks'].values.sum} checks, #{v['failures']} failures)"
      run.validation['failures'].first(5).each { |f| out.puts "  FAIL #{f}" }
      out.puts "Output       #{File.expand_path(run.out_dir)}" if run.out_dir
    end
  end
end
