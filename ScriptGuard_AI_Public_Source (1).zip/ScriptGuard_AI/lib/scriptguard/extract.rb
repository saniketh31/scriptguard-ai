require 'set'
require_relative 'model'

module ScriptGuard
  # Produces the three entity streams, kept separate on purpose:
  #   A. speaker labels   (one per dialogue block; label text only)
  #   B. text mentions    (capitalised spans in dialogue/action/camera/sfx bodies and header notes)
  #   C. location mentions (segments of the scene-heading location part)
  #
  # Stream B does NOT filter by "looks like a name". Every capitalised span is kept with a
  # `name_evidence` class so later sessions can measure what any filter would discard:
  #   proper_noun                        - a core token is capitalised mid-sentence somewhere and never lower case
  #   capitalised_only_at_sentence_start - never lower case, but only ever seen sentence-initially
  #   common_word                        - core tokens also occur in lower case (e.g. "Medium", "Close-up")
  #   title_or_descriptor_only           - only titles/descriptor nouns (e.g. "Lady", "Guard")
  # Only closed-class words (articles, pronouns, auxiliaries...) are trimmed from spans.
  class Extractor
    TOKEN = /(?<![\p{L}\p{N}'’])\p{Lu}[\p{L}\p{M}]*(?:['’]\p{L}+)*(?:-\p{L}[\p{L}\p{M}]*)*/
    LOWER_WORD = /(?<![\p{L}\p{N}'’-])\p{Ll}[\p{Ll}\p{M}]*(?:['’]\p{Ll}+)*(?:-\p{Ll}+)*/
    POSSESSIVE = /['’]s\z/i
    SENTENCE_END = /(\A|[.!?…:;]["”’)\]]*|["“(\[]|--|—)\z/

    Result = Struct.new(:speaker_labels, :text_mentions, :location_mentions, :token_stats, keyword_init: true)

    def initialize(config)
      @titles = Set.new(config['titles'])
      @descriptors = Set.new(config['descriptor_nouns'])
      @closed = Set.new(config['closed_class_words'])
      @connectors = Set.new(config['connector_words'])
      @generic_loc = Set.new(config['generic_location_words'].map(&:upcase))
    end

    # episodes: parsed Episode records; lines_by_key: { episode.key => decoded source lines }
    def call(episodes, lines_by_key)
      @lines_by_key = lines_by_key
      units = text_units(episodes)
      lower = Hash.new(0)
      units.each { |u| u[:text].scan(LOWER_WORD) { |w| lower[w] += 1 } }
      # corpus-wide count of each token capitalised in mid-sentence position (used to split
      # sentence-initial verbs such as "Imagine Élodie" without hard-coding verbs)
      cap_mid = Hash.new(0)
      units.each do |u|
        u[:text].to_enum(:scan, TOKEN).each do
          md = Regexp.last_match
          cap_mid[md[0].sub(POSSESSIVE, '').downcase] += 1 unless sentence_initial?(u[:text], md.begin(0))
        end
      end
      mentions = []
      units.each { |u| mentions.concat(spans(u, lower, cap_mid)) }
      stats = token_stats(mentions, lower)
      mentions.each { |m| m.name_evidence = classify(m, stats) }
      labels = episodes.flat_map { |ep| speaker_labels(ep) }
      locations = episodes.flat_map { |ep| location_mentions(ep, stats) }
      Result.new(speaker_labels: labels, text_mentions: mentions, location_mentions: locations, token_stats: stats)
    end

    private

    # Every piece of free text that may contain names, with its exact line and column origin.
    def text_units(episodes)
      units = []
      episodes.each do |ep|
        { 'logline' => ep.logline, 'continuity' => ep.continuity }.each do |kind, h|
          next unless h
          raw = source_line(ep, h.line)
          col = raw.index(h.text) || 0
          units << { ep: ep, line: h.line, col: col, text: h.text, raw: raw, kind: kind, block: nil }
        end
        ep.blocks.each do |b|
          kind = { 'DIALOGUE' => 'dialogue', 'CAMERA' => 'camera', 'ACTION' => 'action', 'SOUND FX' => 'sfx', 'SFX' => 'sfx' }[b.kind] || b.kind.downcase.tr(' ', '_')
          b.body.each { |bl| units << { ep: ep, line: bl.line, col: 0, text: bl.text, raw: bl.text, kind: kind, block: b } }
        end
      end
      units
    end

    def source_line(ep, n)
      (@lines_by_key[ep.key] || []).fetch(n - 1, '')
    end

    def spans(u, lower, cap_mid)
      toks = []
      u[:text].to_enum(:scan, TOKEN).each { toks << Regexp.last_match }
      groups = []
      toks.each do |m|
        prev = groups.last && groups.last.last
        if prev && !POSSESSIVE.match?(prev[0]) && joinable?(u[:text][prev.end(0)...m.begin(0)])
          groups.last << m
        else
          groups << [m]
        end
      end
      out = []
      groups.each do |g|
        g = g.drop_while { |m| @closed.include?(m[0]) }
        g = g[0...-1] while !g.empty? && @closed.include?(g.last[0])
        next if g.empty?
        initial = sentence_initial?(u[:text], g.first.begin(0))
        first = g.first[0].downcase
        if initial && g.size > 1 && !@titles.include?(g.first[0]) && (lower[first] > 0 || cap_mid[first].zero?)
          out << build(u, [g.first], true, true)
          out << build(u, g[1..-1], false, true)
        else
          out << build(u, g, initial, false)
        end
      end
      out
    end

    def joinable?(gap)
      return true if gap == ' '
      w = gap.strip
      gap.start_with?(' ') && gap.end_with?(' ') && @connectors.include?(w)
    end

    def sentence_initial?(text, pos)
      SENTENCE_END.match?(text[0, pos].rstrip)
    end

    def build(u, g, initial, split)
      ep = u[:ep]
      s = g.first.begin(0)
      e = g.last.end(0)
      surface = u[:text][s...e]
      possessive = POSSESSIVE.match?(surface) && surface.size > 2
      name = possessive ? surface.sub(POSSESSIVE, '') : surface
      tokens = name.split(/\s+/)
      titles = []
      tokens.each { |t| @titles.include?(t) ? titles << t : break }
      descriptors = tokens.select { |t| @descriptors.include?(t) }
      core = tokens.reject { |t| @titles.include?(t) || @descriptors.include?(t) || @connectors.include?(t) || @closed.include?(t) }
      col = u[:col] + s
      TextMention.new(
        id: format('%s-L%05d-C%03d', ep.key, u[:line], col), episode: ep.number, filename: ep.filename,
        line: u[:line], col_start: col, col_end: u[:col] + e, surface: surface, name: name, possessive: possessive,
        tokens: tokens, titles: titles, descriptor_tokens: descriptors, core_tokens: core,
        source_kind: u[:kind], block_id: u[:block] && u[:block].id, scene_number: u[:block] && u[:block].scene_number,
        speaker: u[:block] && u[:block].speaker, sentence_initial: initial, split_at_sentence_start: split,
        all_caps: tokens.all? { |t| t.size > 1 && t == t.upcase }, original_text: u[:raw]
      )
    end

    # Per token (case-folded): capitalised mid-sentence / sentence-initial counts, lower-case count, episodes.
    def token_stats(mentions, lower)
      stats = Hash.new { |h, k| h[k] = { 'cap_mid' => 0, 'cap_initial' => 0, 'lower' => 0, 'episodes' => Set.new, 'forms' => Set.new } }
      mentions.each do |m|
        m.tokens.each_with_index do |t, i|
          st = stats[t.downcase]
          (m.sentence_initial && i.zero? ? st['cap_initial'] += 1 : st['cap_mid'] += 1)
          st['episodes'] << m.episode
          st['forms'] << t
        end
      end
      stats.each { |k, st| st['lower'] = lower[k] }
      stats
    end

    def classify(m, stats)
      return 'title_or_descriptor_only' if m.core_tokens.empty?
      core = m.core_tokens.map { |t| stats[t.downcase] }
      return 'proper_noun' if core.any? { |st| st['cap_mid'] > 0 && st['lower'].zero? }
      return 'capitalised_only_at_sentence_start' if core.all? { |st| st['lower'].zero? }
      'common_word'
    end

    def speaker_labels(ep)
      ep.blocks.select { |b| b.kind == 'DIALOGUE' }.map do |b|
        SpeakerLabel.new(id: format('%s-L%05d-SPK', ep.key, b.label_line), episode: ep.number, filename: ep.filename,
                         scene_number: b.scene_number, block_id: b.id, label_raw: b.label_raw, speaker: b.speaker,
                         parentheticals: b.parentheticals, label_line: b.label_line, text_line: b.text_line,
                         dialogue_text: b.body.map { |x| x.text.strip }.join(' '),
                         timing_start: b.timing && b.timing.start_raw)
      end
    end

    def location_mentions(ep, stats)
      out = []
      ep.scenes.each do |s|
        h = s.heading
        next unless h && !h.location_raw.to_s.strip.empty?
        loc = h.location_raw
        pieces = []
        last = 0
        roles = []
        loc.scan(%r{\s+(?:[-–—/&])\s+}) do
          md = Regexp.last_match
          pieces << [last, md.begin(0)]
          roles << (md[0].strip == '/' || md[0].strip == '&' ? 'alternative' : 'sub')
          last = md.end(0)
        end
        pieces << [last, loc.size]
        pieces.each_with_index do |(a, b), i|
          seg = loc[a...b]
          lead = seg[/\A\s*/].size
          seg = seg.strip
          col = h.location_col + a + lead
          seg_ie = h.int_ext
          # an alternative such as "INT. COTTAGE - PARLOR / EXT. COTTAGE" carries its own prefix
          if (pm = seg.match(%r{\A(INT\.?\s*/\s*EXT\.?|EXT\.?\s*/\s*INT\.?|INT\.|EXT\.)\s*}i))
            seg_ie = pm[1].upcase.delete(' ')
            col += pm[0].size
            seg = seg[pm[0].size..-1]
          end
          next if seg.empty?
          out << location_record(ep, s, h, seg, col, i.zero? ? 'primary' : roles[i - 1], stats, seg_ie)
        end
      end
      out
    end

    def location_record(ep, s, h, seg, col, role, stats, int_ext)
      tokens = seg.scan(/[\p{L}][\p{L}\p{M}'’-]*|&/)
      owner_idx = tokens.index { |t| t =~ /['’]S\z/i }
      owner = owner_idx ? tokens[0..owner_idx].join(' ') : nil
      owner_tokens = owner_idx ? tokens[0..owner_idx] : []
      generic = tokens.select { |t| @generic_loc.include?(t.upcase) }
      non_generic = tokens - generic - owner_tokens
      evid = non_generic.map do |t|
        st = stats.key?(t.downcase) ? stats[t.downcase] : nil
        if st.nil? then 'heading_only'
        elsif st['lower'] > 0 then 'common_word'
        elsif st['cap_mid'] > 0 then 'proper_noun_in_text'
        else 'heading_only'
        end
      end
      best = %w[proper_noun_in_text heading_only common_word].find { |c| evid.include?(c) } || (owner ? 'possessive_only' : 'generic_only')
      LocationMention.new(id: format('%s-L%05d-C%03d-LOC', ep.key, h.line, col), episode: ep.number, filename: ep.filename,
                          scene_number: s.number, line: h.line, col_start: col, col_end: col + seg.size, segment: seg,
                          role: role, int_ext: int_ext, time_of_day: h.time_of_day, heading_raw: h.raw,
                          tokens: tokens, generic_tokens: generic, possessive_owner: owner,
                          non_generic_tokens: non_generic, name_evidence: best)
    end
  end
end
