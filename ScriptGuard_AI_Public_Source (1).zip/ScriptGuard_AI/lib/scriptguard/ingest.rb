require 'digest'
require_relative 'model'
require_relative 'zip_reader'

module ScriptGuard
  # Reads a ZIP archive or a directory, decodes every candidate file, identifies episode
  # numbers and reports problems. Never writes to the input location.
  class Ingest
    Result = Struct.new(:input_path, :input_kind, :input_sha256, :sources, :issues, :skipped,
                        :expected_range, :missing, :duplicates, keyword_init: true)

    SYSTEM_FILE = %r{(\A|/)(__MACOSX/|\.DS_Store\z|\._|Thumbs\.db\z|desktop\.ini\z)}i

    def initialize(config)
      @config = config
      @patterns = config['episode_filename_patterns'].map { |p| Regexp.new(p, Regexp::IGNORECASE) }
      @exts = config['supported_extensions'].map(&:downcase)
    end

    # expect: optional Range of episode numbers (e.g., 1..50)
    def call(path, expect: nil)
      path = File.expand_path(path)
      issues = []
      skipped = []
      kind, sha, raw_files = discover(path, issues)
      sources = []
      raw_files.each do |rel, bytes_or_error|
        if SYSTEM_FILE.match?(rel)
          skipped << rel
          next
        end
        if bytes_or_error.is_a?(Exception)
          issues << Issue.new(severity: 'error', code: 'unreadable_file', message: bytes_or_error.message, file: rel)
          next
        end
        ext = File.extname(rel).downcase
        unless @exts.include?(ext)
          issues << Issue.new(severity: 'warning', code: 'unsupported_file',
                              message: "ignored: extension #{ext.empty? ? '(none)' : ext} is not supported", file: rel)
          next
        end
        src = decode(rel, bytes_or_error, issues)
        next unless src

        identify(src, issues)
        sources << src
      end
      ranged = mark_missing_and_duplicates(sources, expect, issues)
      Result.new(input_path: path, input_kind: kind, input_sha256: sha, sources: sources.sort_by { |s| [s.episode_number || 1 << 30, s.path] },
                 issues: issues, skipped: skipped, expected_range: ranged[:range], missing: ranged[:missing],
                 duplicates: ranged[:duplicates])
    end

    # Re-reads one source's bytes independently (used by validation).
    def self.reread(input_path, input_kind, rel, config)
      if input_kind == 'zip'
        z = ZipReader.new(input_path, config['limits'])
        e = z.entries.find { |x| x.name == rel }
        z.read(e)
      else
        File.binread(File.join(input_path, rel))
      end
    end

    # Decodes bytes into UTF-8 lines. Public so validation can reuse exactly the same rules.
    def self.decode_bytes(bytes)
      info = { 'bom' => nil, 'encoding' => 'UTF-8', 'invalid_bytes' => 0, 'first_invalid_line' => nil, 'transcoded_from' => nil }
      b = bytes.dup.force_encoding(Encoding::BINARY)
      if b.start_with?("\xEF\xBB\xBF".b)
        info['bom'] = 'UTF-8'
        b = b.byteslice(3, b.bytesize - 3)
      elsif b.start_with?("\xFF\xFE".b) || b.start_with?("\xFE\xFF".b)
        enc = b.start_with?("\xFF\xFE".b) ? 'UTF-16LE' : 'UTF-16BE'
        info['bom'] = enc
        info['transcoded_from'] = enc
        b = b.byteslice(2, b.bytesize - 2).force_encoding(enc).encode('UTF-8', invalid: :replace, undef: :replace).b
      end
      text = b.force_encoding('UTF-8')
      unless text.valid_encoding?
        bad_line = nil
        text.b.split("\n", -1).each_with_index do |l, i|
          next if l.dup.force_encoding('UTF-8').valid_encoding?
          bad_line = i + 1
          break
        end
        info['invalid_bytes'] = text.each_char.count { |c| !c.valid_encoding? }
        info['first_invalid_line'] = bad_line
        info['encoding'] = 'UTF-8 (invalid bytes replaced with U+FFFD)'
        text = text.scrub("�")
      end
      info['encoding'] = 'ASCII' if info['encoding'] == 'UTF-8' && text.ascii_only?
      crlf = text.scan("\r\n").size
      lone_cr = text.scan(/\r(?!\n)/).size
      lf = text.scan(/(?<!\r)\n/).size
      styles = { 'CRLF' => crlf, 'CR' => lone_cr, 'LF' => lf }.select { |_, v| v > 0 }.keys
      info['line_ending'] = styles.empty? ? 'none' : (styles.size == 1 ? styles.first : "mixed(#{styles.join('+')})")
      lines = text.split(/\r\n|\n|\r/, -1)
      lines.pop if lines.last == '' && lines.size > 1
      [lines, info]
    end

    private

    def discover(path, issues)
      if File.directory?(path)
        files = []
        root = File.realpath(path)
        Dir.glob('**/*', File::FNM_DOTMATCH, base: path).sort.each do |rel|
          full = File.join(path, rel)
          next if File.directory?(full) && !File.symlink?(full)
          if File.symlink?(full)
            issues << Issue.new(severity: 'warning', code: 'symlink_skipped', message: 'symbolic links are not followed', file: rel)
            next
          end
          real = File.realpath(full)
          unless real.start_with?(root + File::SEPARATOR)
            issues << Issue.new(severity: 'error', code: 'outside_input', message: 'file resolves outside the input folder', file: rel)
            next
          end
          files << [rel, read_file(full)]
        end
        ['directory', nil, files]
      elsif File.file?(path)
        sha = Digest::SHA256.file(path).hexdigest
        begin
          zip = ZipReader.new(path, @config['limits'])
        rescue ZipReader::Error => e
          raise Error, "cannot read archive: #{e.message}"
        end
        files = []
        zip.entries.each do |e|
          next if e.directory?
          if e.unsafe_reason
            issues << Issue.new(severity: 'error', code: 'unsafe_archive_entry', message: "not read: #{e.unsafe_reason}", file: e.name)
            next
          end
          begin
            files << [e.name, zip.read(e)]
          rescue ZipReader::Error => err
            files << [e.name, err]
          end
        end
        ['zip', sha, files]
      else
        raise Error, "input not found: #{path}"
      end
    end

    def read_file(full)
      File.binread(full)
    rescue SystemCallError, IOError => e
      e
    end

    def decode(rel, bytes, issues)
      sha = Digest::SHA256.hexdigest(bytes)
      if bytes.bytesize.zero?
        issues << Issue.new(severity: 'error', code: 'empty_file', message: 'file is empty', file: rel)
        return nil
      end
      nul = bytes.count("\0")
      if nul > 0 && !bytes.start_with?("\xFF\xFE".b, "\xFE\xFF".b)
        issues << Issue.new(severity: 'error', code: 'binary_file', message: "file contains #{nul} NUL bytes; not a text screenplay", file: rel)
        return nil
      end
      lines, info = self.class.decode_bytes(bytes)
      if info['invalid_bytes'] > 0
        issues << Issue.new(severity: 'warning', code: 'invalid_utf8',
                            message: "#{info['invalid_bytes']} invalid byte sequence(s) replaced with U+FFFD; line numbers preserved",
                            file: rel, line: info['first_invalid_line'])
      end
      if info['transcoded_from']
        issues << Issue.new(severity: 'warning', code: 'transcoded', message: "decoded from #{info['transcoded_from']}", file: rel)
      end
      if info['line_ending'].start_with?('mixed') || info['line_ending'] == 'CR'
        issues << Issue.new(severity: 'warning', code: 'line_endings', message: "line endings: #{info['line_ending']}", file: rel)
      end
      SourceFile.new(path: rel, filename: File.basename(rel), size: bytes.bytesize, sha256: sha,
                     encoding: info['encoding'], bom: info['bom'], line_ending: info['line_ending'],
                     lines: lines, duplicate: false, status: 'decoded')
    end

    def identify(src, issues)
      from_name = nil
      @patterns.each do |re|
        m = src.filename.match(re)
        next unless m
        from_name = m[1].to_i
        break
      end
      header = nil
      src.lines.first(10).each do |l|
        m = l.match(/\AEPISODE NUMBER:\s*(?:Episode\s*)?0*(\d+)/i)
        next unless m
        header = m[1].to_i
        break
      end
      src.header_episode_number = header
      if from_name
        src.episode_number = from_name
        src.episode_number_source = 'filename'
        if header && header != from_name
          issues << Issue.new(severity: 'warning', code: 'episode_number_mismatch',
                              message: "filename says episode #{from_name}, header says #{header}; using filename",
                              file: src.path, episode: from_name)
        end
      elsif header
        src.episode_number = header
        src.episode_number_source = 'header'
        issues << Issue.new(severity: 'info', code: 'episode_from_header', message: "no episode number in filename; used header (#{header})",
                            file: src.path, episode: header)
      else
        src.episode_number_source = 'none'
        issues << Issue.new(severity: 'error', code: 'unidentified_episode',
                            message: 'no episode number in filename or header; file will not be parsed', file: src.path)
      end
    end

    def mark_missing_and_duplicates(sources, expect, issues)
      nums = sources.map(&:episode_number).compact
      range = expect || (nums.empty? ? nil : (1..nums.max))
      missing = range ? range.to_a - nums : []
      missing.each do |n|
        issues << Issue.new(severity: 'error', code: 'missing_episode', message: "episode #{n} not found", episode: n)
      end
      if expect
        (nums.uniq - expect.to_a).each do |n|
          issues << Issue.new(severity: 'warning', code: 'unexpected_episode', message: "episode #{n} is outside the expected range #{expect}", episode: n)
        end
      end
      dups = sources.select(&:episode_number).group_by(&:episode_number).select { |_, v| v.size > 1 }
      dups.each do |n, srcs|
        srcs.each { |s| s.duplicate = true }
        issues << Issue.new(severity: 'error', code: 'duplicate_episode',
                            message: "episode #{n} appears in #{srcs.size} files: #{srcs.map(&:path).join(' | ')}", episode: n)
      end
      { range: range, missing: missing, duplicates: dups.keys.sort }
    end
  end

  class Error < StandardError; end
end
