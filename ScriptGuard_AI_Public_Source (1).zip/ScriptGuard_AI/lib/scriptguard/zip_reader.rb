require 'zlib'

module ScriptGuard
  # Minimal, read-only ZIP reader (stdlib only). Entries are read into memory; nothing is
  # ever extracted to disk, so path-traversal entries cannot write anywhere. Unsafe entries
  # are reported (not read). Supports stored (0) and deflate (8) entries; rejects ZIP64,
  # encryption and other methods with explicit errors.
  class ZipReader
    class Error < StandardError; end

    Entry = Struct.new(:name, :method, :flags, :crc, :csize, :usize, :local_offset,
                       :external_attr, :made_by, :unsafe_reason, keyword_init: true) do
      def directory?
        name.end_with?('/')
      end
    end

    EOCD_SIG = [0x06054b50].pack('V')
    CEN_SIG = 0x02014b50
    LOC_SIG = 0x04034b50

    attr_reader :entries

    def initialize(path, limits = {})
      @path = path
      @limits = limits
      size = File.size(path)
      max = limits['max_archive_bytes'] || 200 * 1024 * 1024
      raise Error, "archive is #{size} bytes, above limit #{max}" if size > max

      @data = File.binread(path)
      @entries = read_central_directory
    end

    # Returns the decompressed bytes of a safe entry (binary string). Verifies size and CRC.
    def read(entry)
      raise Error, "refusing unsafe entry #{entry.name.inspect}: #{entry.unsafe_reason}" if entry.unsafe_reason

      off = entry.local_offset
      raise Error, "bad local header offset for #{entry.name}" if off + 30 > @data.bytesize
      sig, = @data.byteslice(off, 4).unpack('V')
      raise Error, "bad local header signature for #{entry.name}" unless sig == LOC_SIG

      name_len, extra_len = @data.byteslice(off + 26, 4).unpack('vv')
      start = off + 30 + name_len + extra_len
      raw = @data.byteslice(start, entry.csize)
      raise Error, "truncated data for #{entry.name}" if raw.nil? || raw.bytesize != entry.csize

      out = case entry.method
            when 0 then raw
            when 8 then inflate_limited(raw, entry.usize)
            else raise Error, "unsupported compression method #{entry.method} for #{entry.name}"
            end
      raise Error, "size mismatch for #{entry.name}" unless out.bytesize == entry.usize
      raise Error, "CRC mismatch for #{entry.name} (corrupt archive)" unless Zlib.crc32(out) == entry.crc

      out
    end

    private

    def read_central_directory
      tail_start = [@data.bytesize - 65_557, 0].max
      idx = @data.rindex(EOCD_SIG, @data.bytesize - 22)
      raise Error, 'not a ZIP archive (end-of-central-directory record not found)' if idx.nil? || idx < tail_start

      _sig, _disk, _cd_disk, _n_disk, n_total, cd_size, cd_off = @data.byteslice(idx, 22).unpack('VvvvvVV')
      raise Error, 'ZIP64 archives are not supported' if n_total == 0xFFFF || cd_off == 0xFFFFFFFF || cd_size == 0xFFFFFFFF
      max_entries = @limits['max_entries'] || 5000
      raise Error, "archive has #{n_total} entries, above limit #{max_entries}" if n_total > max_entries
      raise Error, 'central directory lies outside the file' if cd_off + cd_size > idx

      entries = []
      pos = cd_off
      n_total.times do
        raise Error, 'truncated central directory' if pos + 46 > @data.bytesize
        f = @data.byteslice(pos, 46).unpack('VvvvvvvVVVvvvvvVV')
        raise Error, 'bad central directory signature' unless f[0] == CEN_SIG

        made_by, flags, method, crc, csize, usize = f[1], f[3], f[4], f[7], f[8], f[9]
        name_len, extra_len, comment_len, ext_attr, local_off = f[10], f[11], f[12], f[15], f[16]
        raw_name = @data.byteslice(pos + 46, name_len)
        entries << build_entry(raw_name, flags, method, crc, csize, usize, local_off, ext_attr, made_by)
        pos += 46 + name_len + extra_len + comment_len
      end
      enforce_total_limit(entries)
      entries
    end

    def build_entry(raw_name, flags, method, crc, csize, usize, local_off, ext_attr, made_by)
      name = decode_name(raw_name, flags)
      e = Entry.new(name: name, method: method, flags: flags, crc: crc, csize: csize, usize: usize,
                    local_offset: local_off, external_attr: ext_attr, made_by: made_by)
      e.unsafe_reason = unsafe_reason(e, raw_name)
      e
    end

    def decode_name(raw, flags)
      s = raw.dup.force_encoding('UTF-8')
      return s if s.valid_encoding? || (flags & 0x800) != 0

      raw.dup.force_encoding('IBM437').encode('UTF-8', invalid: :replace, undef: :replace)
    end

    def unsafe_reason(e, raw_name)
      n = e.name.tr('\\', '/')
      return 'NUL byte in entry name' if raw_name.include?("\0")
      return 'absolute path' if n.start_with?('/') || n =~ /\A[A-Za-z]:/
      return 'path traversal (..)' if n.split('/').include?('..')
      return 'backslash in entry name' if e.name.include?('\\')
      return 'encrypted entry' if (e.flags & 0x1) != 0
      return 'symbolic link' if symlink?(e)
      return "unsupported compression method #{e.method}" unless e.directory? || [0, 8].include?(e.method)
      max = @limits['max_entry_bytes'] || 5 * 1024 * 1024
      return "uncompressed size #{e.usize} above limit #{max}" if e.usize > max && !e.directory?
      nil
    end

    def symlink?(e)
      (e.made_by >> 8) == 3 && ((e.external_attr >> 16) & 0o170000) == 0o120000
    end

    def enforce_total_limit(entries)
      max = @limits['max_total_uncompressed_bytes'] || 200 * 1024 * 1024
      total = 0
      entries.each do |e|
        next if e.unsafe_reason || e.directory?
        total += e.usize
        e.unsafe_reason = 'archive total uncompressed size above limit' if total > max
      end
    end

    def inflate_limited(raw, expected)
      z = Zlib::Inflate.new(-Zlib::MAX_WBITS)
      out = +''
      out.force_encoding(Encoding::BINARY)
      offset = 0
      while offset < raw.bytesize
        out << z.inflate(raw.byteslice(offset, 65_536))
        offset += 65_536
        raise Error, 'decompressed data exceeds declared size' if out.bytesize > expected
      end
      out << z.finish
      raise Error, 'decompressed data exceeds declared size' if out.bytesize > expected
      out
    rescue Zlib::Error => e
      raise Error, "corrupt deflate stream: #{e.message}"
    ensure
      z&.close
    end
  end
end
