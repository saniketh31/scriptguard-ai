module ScriptGuard
  # Plain data records. All line numbers are 1-based physical lines of the decoded source
  # file; all columns are 0-based character offsets into that line (end exclusive).
  # Every record converts to a JSON-ready Hash via #to_h (nested records included).
  module Record
    def to_h
      members.each_with_object({}) do |m, h|
        h[m.to_s] = Record.plain(self[m])
      end
    end

    def self.plain(v)
      case v
      when Record then v.to_h
      when Array then v.map { |x| plain(x) }
      when Hash then v.each_with_object({}) { |(k, x), h| h[k.to_s] = plain(x) }
      else v
      end
    end
  end

  def self.record(*fields)
    Struct.new(*fields, keyword_init: true) { include Record }
  end

  # severity: "error" | "warning" | "info"
  Issue = record(:severity, :code, :message, :file, :episode, :line)

  # A decoded input file. `lines` are raw text lines without line terminators.
  SourceFile = record(:key, :path, :filename, :size, :sha256, :encoding, :bom, :line_ending,
                      :lines, :episode_number, :episode_number_source, :header_episode_number,
                      :duplicate, :status)

  Timing = record(:start_raw, :end_raw, :start_s, :end_s, :line)
  Header = record(:text, :line)
  Heading = record(:raw, :line, :int_ext, :location_raw, :location_col, :time_of_day)
  Scene = record(:id, :number, :line, :heading, :start, :end, :field_case, :block_ids)
  BodyLine = record(:line, :text)
  # kind: "DIALOGUE" | "CAMERA" | "ACTION" | "SOUND FX" | other configured non-dialogue label
  Block = record(:id, :episode, :scene_number, :kind, :label_raw, :label_line, :speaker,
                 :parentheticals, :timing, :body, :text_line)
  Episode = record(:key, :number, :filename, :path, :header_episode_number, :logline, :continuity,
                   :scenes, :blocks, :line_count, :status, :duplicate)

  # Stream A
  SpeakerLabel = record(:id, :episode, :filename, :scene_number, :block_id, :label_raw, :speaker,
                        :parentheticals, :label_line, :text_line, :dialogue_text, :timing_start)
  # Stream B
  TextMention = record(:id, :episode, :filename, :line, :col_start, :col_end, :surface, :name,
                       :possessive, :tokens, :titles, :descriptor_tokens, :core_tokens,
                       :source_kind, :block_id, :scene_number, :speaker, :sentence_initial, :split_at_sentence_start,
                       :all_caps, :name_evidence, :original_text)
  # Stream C
  LocationMention = record(:id, :episode, :filename, :scene_number, :line, :col_start, :col_end,
                           :segment, :role, :int_ext, :time_of_day, :heading_raw, :tokens,
                           :generic_tokens, :possessive_owner, :non_generic_tokens,
                           :name_evidence)
end
