require_relative 'detect/text'
require_relative 'detect/corpus'
require_relative 'detect/candidates'
require_relative 'detect/detector'
require_relative 'detect/report'

module ScriptGuard
  # Session 3: deterministic detection on top of a Session-2 parse run.
  module Detect
    Outcome = Struct.new(:findings, :stats, :files, :out_dir, keyword_init: true)

    # run_dir: folder written by `scriptguard parse`. out_dir: where reports go (defaults to run_dir).
    def self.run(run_dir, config, out_dir: nil)
      out_dir ||= run_dir
      corpus = Corpus.load(run_dir, config)
      det = Detector.new(corpus)
      findings = det.call
      files = Report.new(corpus, findings, det.stats, out_dir).write
      Outcome.new(findings: findings, stats: det.stats, files: files, out_dir: out_dir)
    end
  end
end
