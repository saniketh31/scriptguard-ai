require 'json'
require 'digest'
require 'fileutils'
require 'time'
require_relative 'ingest'
require_relative 'parser'
require_relative 'extract'
require_relative 'validate'

module ScriptGuard
  VERSION = '1.0.0'

  # Orchestrates ingest -> parse -> extract -> validate -> write. Read-only on the input.
  class Pipeline
    Run = Struct.new(:summary, :issues, :episodes, :streams, :validation, :exit_code, :out_dir, keyword_init: true)

    def self.load_config(path = nil)
      path ||= File.expand_path('../../config/defaults.json', __dir__)
      JSON.parse(File.read(path))
    end

    def initialize(config = Pipeline.load_config)
      @config = config
    end

    # input: zip path or directory. out_dir: where JSON outputs go (nil = do not write).
    def run(input, out_dir: nil, expect: nil)
      input = File.expand_path(input)
      raise Error, "input not found: #{input}" unless File.exist?(input)
      raise Error, "input is neither a file nor a folder: #{input}" unless File.file?(input) || File.directory?(input)
      guard_out_dir!(input, out_dir) if out_dir
      before = fingerprint(input)

      ing = Ingest.new(@config).call(input, expect: expect)
      assign_keys(ing.sources)
      parser = Parser.new(@config)
      issues = ing.issues.dup
      episodes = []
      ing.sources.each do |src|
        next unless src.key
        ep, ep_issues = parser.parse(src)
        issues.concat(ep_issues)
        if ep.status != 'failed'
          sev = ep_issues.map(&:severity)
          ep.status = if sev.include?('error') then 'parsed_with_errors'
                      elsif sev.include?('warning') then 'parsed_with_warnings'
                      else 'parsed'
                      end
        end
        src.status = ep.status
        episodes << ep
      end
      parsed = episodes.reject { |e| e.status == 'failed' }
      streams = Extractor.new(@config).call(parsed, ing.sources.select(&:key).map { |s| [s.key, s.lines] }.to_h)
      validation = Validator.new(@config).call(ing, parsed, streams)
      after = fingerprint(input)
      unchanged = before == after
      issues << Issue.new(severity: 'error', code: 'input_changed', message: 'input fingerprint changed during the run') unless unchanged

      summary = build_summary(ing, episodes, streams, validation, issues, before, after)
      code = if !validation['passed'] || !unchanged then 2
             elsif issues.any? { |x| x.severity == 'error' } then 1
             else 0
             end
      run = Run.new(summary: summary, issues: issues, episodes: episodes, streams: streams, validation: validation,
                    exit_code: code, out_dir: out_dir)
      write(run, ing) if out_dir
      run
    end

    private

    def guard_out_dir!(input, out_dir)
      out = File.expand_path(out_dir)
      base = File.directory?(input) ? input : File.dirname(input)
      raise Error, 'output directory must differ from the input' if out == input
      if File.directory?(input) && (out + '/').start_with?(input + '/')
        raise Error, 'output directory must not be inside the input folder'
      end
      raise Error, 'output path is an existing file' if File.file?(out)
      base
    end

    def fingerprint(input)
      self.class.fingerprint(input)
    end

    # SHA-256 of a ZIP, or of every regular file (path + content hash) in a folder.
    def self.fingerprint(input)
      if File.directory?(input)
        files = Dir.glob('**/*', File::FNM_DOTMATCH, base: input).sort.select { |r| File.file?(File.join(input, r)) && !File.symlink?(File.join(input, r)) }
        Digest::SHA256.hexdigest(files.map { |r| "#{r}\0#{Digest::SHA256.file(File.join(input, r)).hexdigest}" }.join("\n"))
      else
        Digest::SHA256.file(input).hexdigest
      end
    end

    def assign_keys(sources)
      sources.select(&:episode_number).group_by(&:episode_number).each do |n, group|
        group.sort_by(&:path).each_with_index do |s, i|
          s.key = group.size == 1 ? format('ep%03d', n) : format('ep%03d-f%d', n, i + 1)
        end
      end
    end

    def count_by(items)
      items.each_with_object(Hash.new(0)) { |x, h| h[x] += 1 }.sort_by { |k, v| [-v, k.to_s] }.to_h
    end

    def build_summary(ing, episodes, streams, validation, issues, before, after)
      blocks = episodes.flat_map(&:blocks)
      {
        'tool' => "ScriptGuard #{VERSION}", 'run_at' => Time.now.utc.iso8601,
        'input' => { 'path' => ing.input_path, 'kind' => ing.input_kind, 'fingerprint_before' => before,
                     'fingerprint_after' => after, 'unchanged' => before == after },
        'files' => { 'read' => ing.sources.size + issues.count { |x| %w[empty_file binary_file unreadable_file].include?(x.code) },
                     'skipped_system_files' => ing.skipped.size,
                     'unsupported' => issues.count { |x| x.code == 'unsupported_file' },
                     'unsafe_archive_entries' => issues.count { |x| x.code == 'unsafe_archive_entry' } },
        'episodes' => { 'discovered' => ing.sources.count(&:key), 'unidentified' => ing.sources.count { |s| s.key.nil? },
                        'expected_range' => ing.expected_range && "#{ing.expected_range.first}-#{ing.expected_range.last}",
                        'missing' => ing.missing, 'duplicates' => ing.duplicates,
                        'status' => count_by(episodes.map(&:status)) },
        'structure' => { 'scenes' => episodes.sum { |e| e.scenes.size }, 'blocks' => blocks.size,
                         'blocks_by_kind' => count_by(blocks.map(&:kind)) },
        'stream_a_speaker_labels' => { 'mentions' => streams.speaker_labels.size,
                                       'distinct_labels' => streams.speaker_labels.map(&:speaker).uniq.size },
        'stream_b_text_mentions' => { 'mentions' => streams.text_mentions.size,
                                      'distinct_names' => streams.text_mentions.map(&:name).uniq.size,
                                      'by_name_evidence' => count_by(streams.text_mentions.map(&:name_evidence)),
                                      'by_source_kind' => count_by(streams.text_mentions.map(&:source_kind)) },
        'stream_c_location_mentions' => { 'mentions' => streams.location_mentions.size,
                                          'distinct_segments' => streams.location_mentions.map(&:segment).uniq.size,
                                          'by_name_evidence' => count_by(streams.location_mentions.map(&:name_evidence)) },
        'issues' => { 'errors' => issues.count { |x| x.severity == 'error' }, 'warnings' => issues.count { |x| x.severity == 'warning' },
                      'info' => issues.count { |x| x.severity == 'info' }, 'by_code' => count_by(issues.map(&:code)) },
        'validation' => { 'passed' => validation['passed'], 'failures' => validation['failure_count'], 'checks' => validation['checks'] }
      }
    end

    def write(run, ing)
      dir = File.expand_path(run.out_dir)
      FileUtils.mkdir_p(dir)
      w = ->(name, obj) { File.write(File.join(dir, name), JSON.pretty_generate(obj) + "\n") }
      jl = lambda do |name, recs|
        File.open(File.join(dir, name), 'w') { |f| recs.each { |r| f.puts(JSON.generate(r.to_h)) } }
      end
      w.('manifest.json', run.summary.merge(
        'sources' => ing.sources.map { |s| s.to_h.reject { |k, _| k == 'lines' }.merge('line_count' => s.lines.size) },
        'outputs' => %w[manifest.json issues.json episodes.json speaker_labels.jsonl text_mentions.jsonl location_mentions.jsonl token_stats.json validation.json],
        'confidentiality' => 'Contains screenplay text and excerpts. Do not publish.'))
      w.('issues.json', run.issues.map(&:to_h))
      w.('episodes.json', run.episodes.map(&:to_h))
      jl.('speaker_labels.jsonl', run.streams.speaker_labels)
      jl.('text_mentions.jsonl', run.streams.text_mentions)
      jl.('location_mentions.jsonl', run.streams.location_mentions)
      stats = run.streams.token_stats.select { |_, v| v['cap_mid'] + v['cap_initial'] > 0 }
                 .sort.map { |k, v| [k, v.merge('episodes' => v['episodes'].to_a.sort, 'forms' => v['forms'].to_a.sort)] }.to_h
      w.('token_stats.json', stats)
      w.('validation.json', run.validation)
    end
  end
end
