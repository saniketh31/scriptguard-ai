# Data model (Session 2 outputs)

Conventions: `line` = 1-based physical line in the decoded source file, which is unchanged by CRLF/LF differences and by invalid-byte replacement. `col_start`/`col_end` = 0-based character offsets into that line (end exclusive), so `line_text[col_start...col_end] == surface`. IDs are stable for the same input: `<key>-L<line>-C<col>[-LOC]`, `<key>-L<label_line>-SPK`. `key` is `ep001`, or `ep001-f1` / `ep001-f2` when an episode number is duplicated.

## episodes.json: one object per identified file
| field | meaning |
|---|---|
| key, number, filename, path | identity; `path` is the path inside the ZIP or folder |
| header_episode_number | value of `EPISODE NUMBER:` (null if absent) |
| logline, continuity | `{text, line}` |
| status | `parsed` · `parsed_with_warnings` · `parsed_with_errors` · `failed` |
| duplicate | true if another file has the same episode number |
| scenes[] | `{id, number, line, heading{raw, line, int_ext, location_raw, location_col, time_of_day}, start{start_raw,start_s,line}, end{…}, field_case, block_ids[]}` |
| blocks[] | `{id, scene_number, kind, label_raw, label_line, speaker, parentheticals[], timing{start_raw,end_raw,start_s,end_s,line}, body[{line,text}], text_line}`. `kind` is `DIALOGUE` or the non-dialogue label (`CAMERA`, `ACTION`, `SOUND FX`, …). `speaker` is set only for dialogue. `text_line` is the first body line, **not** the label line. |

## speaker_labels.jsonl: stream A (one per dialogue block)
`id, episode, filename, scene_number, block_id, label_raw, speaker, parentheticals[], label_line, text_line, dialogue_text, timing_start`
`speaker` is the label with every trailing parenthetical removed (`ÉLODIE (Off-screen) (Calm, Certain)` → `ÉLODIE`). Labels are never merged or normalised.

## text_mentions.jsonl: stream B (capitalised spans in body text and header notes)
| field | meaning |
|---|---|
| surface / name | exact text / text without a possessive `'s` |
| tokens, titles, descriptor_tokens, core_tokens | split of `name`; leading titles (config `titles`); descriptor nouns (config); remaining tokens |
| possessive, all_caps | flags |
| source_kind | `dialogue` · `action` · `camera` · `sfx` · `logline` · `continuity` |
| block_id, scene_number, speaker | context (speaker only for dialogue) |
| sentence_initial | span starts a sentence or quotation |
| split_at_sentence_start | span came from splitting a sentence-initial word off a name (e.g., "Imagine Élodie") |
| name_evidence | `proper_noun` (a core token is capitalised mid-sentence somewhere and never lower case) · `capitalised_only_at_sentence_start` · `common_word` (a core token also appears lower case) · `title_or_descriptor_only` |
| original_text | full source line |

Nothing is filtered by `name_evidence`. Session 3 decides what to use, and can measure what a strict filter would drop.
Spans join capitalised words separated by one space, or by a connector (`of`, `de`, …) such as "Duke of Vellacourt". Leading or trailing closed-class words (`The`, `I'm`, …) are trimmed.

## location_mentions.jsonl: stream C (scene-heading location segments only)
`id, episode, filename, scene_number, line, col_start, col_end, segment, role (primary|sub|alternative), int_ext, time_of_day, heading_raw, tokens[], generic_tokens[], possessive_owner, non_generic_tokens[], name_evidence`
`name_evidence`: `proper_noun_in_text` (a non-generic token appears as a proper noun in body text) · `heading_only` · `common_word` · `possessive_only` (e.g., `TOBIN'S STUDY`) · `generic_only` (e.g., `GREAT HALL`). A heading word is **not** assumed to be a name.

## token_stats.json
Per case-folded token: `cap_mid`, `cap_initial`, `lower`, `episodes[]`, `forms[]`. This is the evidence behind `name_evidence`.

## issues.json
`{severity: error|warning|info, code, message, file, episode, line}`. Codes include `missing_episode`, `duplicate_episode`, `unidentified_episode`, `episode_number_mismatch`, `unsupported_file`, `empty_file`, `binary_file`, `unreadable_file`, `unsafe_archive_entry`, `invalid_utf8`, `transcoded`, `line_endings`, `symlink_skipped`, `unrecognised_line`, `missing_timing`, `orphan_timing`, `unparsable_time`, `ambiguous_label`, `empty_block`, `block_outside_scene`, `no_scenes`, `no_blocks`, `input_changed`.

## validation.json
`{passed, checks{…}, failure_count, failures[]}`. Each source is re-read from the input and decoded again. Every block label, body line, heading, speaker label, text-mention slice and location slice is compared with that fresh copy. Counts of `Start:`, `SCENE` and `**…**` lines (simple regexes, independent of the parser) must equal the parsed totals.
