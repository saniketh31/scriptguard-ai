# ScriptGuard report: detect_show

_Generated 2026-11-18T11:47:43Z · 6 episodes · deterministic rules only (no AI model) · **contains script excerpts: do not share outside the team**._

## At a glance

| Section | Findings | What it means |
|---|---:|---|
| 1. Check first | 2 | The scripts themselves link these forms to one character or place. |
| 2. Worth checking | 2 | Spellings are close, but no line in the scripts links them. They may or may not be the same. |
| 3. Needs your judgement | 2 | The evidence points both ways or is too thin to call. |
| 4. Probably intentional | 1 | Looks like a deliberate choice, such as a title or a description used before a name is revealed. |
| 5. Checked: probably different | 2 | These look alike but the scripts show they are different. Listed so you can confirm. |

Every quoted line below was re-checked against the original script files (39 lines checked).

**How to use this:** work through sections 1–3. For each finding, decide in `findings.csv` (column `review_status`): `confirmed_error`, `confirmed_alias`, `intentional_variation`, `different_entities` or `unresolved`. The tool never edits the scripts. _Confidence_ = how sure the tool is that the forms mean the same person or place. _Importance_ = how much it matters if they do.

## 1. Check first (2)

_The scripts themselves link these forms to one character or place._

### SG-001 · Place-name variation · importance: medium · confidence: high

| Form | Times | Episodes | First seen | In dialogue |
|---|---:|---|---|---:|
| **Greymoor** | 5 | 1–3 | ep1:L2 | 1 |
| **Greymoore** | 2 | 3–4 | ep3:L24 | 1 |

**Why flagged:** 2 spellings share the first 3 letters and are close in spelling (rule G1): Greymoor–Greymoore (similarity 0.889). B3: "Greymoor" and "Greymoore" both name the same kind of place (abbey) in the same scene (ep3 L8 and L24).

**Evidence:**
- Ep 3, line 8 (scene heading): Scene heading: INT. **GREYMOOR** ABBEY - CLOISTER – NIGHT
- Ep 3, line 24 (dialogue, MARA): "Then welcome to **Greymoore** Abbey, Tobin."
- Ep 1, line 2 (logline): … Lady Mara Vellacourt meets the Hooded Rider on the road to **Greymoor** Abbey.
- Ep 1, line 28 (dialogue, HOODED RIDER): "Turn back before you reach **Greymoor** Abbey."
- Ep 4, line 8 (scene heading): Scene heading: EXT. **GREYMOORE** ABBEY - GATE – DAY
- Ep 2, line 2 (logline): …in Vale and Tobias Vale quarrel while Lord Greyson rides to **Greymoor** Abbey.

**Suggested action:** Confirm the canonical spelling in the show bible; mark the other forms as errors or approved aliases. (most frequent form: _Greymoor_)

### SG-002 · Same character, different speaker labels · importance: medium · confidence: high

| Form | Times | Episodes | First seen | In dialogue |
|---|---:|---|---|---:|
| **HOODED RIDER** | 3 | 1, 3–4 | ep1:L26 | 3 |
| **TOBIN** | 1 | 2 | ep2:L18 | 1 |

**Why flagged:** B2: 1 line(s) where speaker names themself ("Tobin Vale"). B1: 1 line(s) where descriptor followed by name in one phrase ("Tobin"). G5 timeline: HOODED RIDER speaks in episode(s) 1, 3, 4; TOBIN in 2. The name first appears in episode 2; label uses before that (1) look like an intentional description before the reveal. The label is still used after the name is known, in episode(s) 3, 4.

**Evidence:**
- Ep 3, line 20 (dialogue, HOODED RIDER): "I am **Lord Tobin Vale**!"
- Ep 3, line 16 (action): **Hooded Rider Tobin** pulls back his hood beside Mara.
- Ep 1, line 26 (speaker label): `**HOODED RIDER (Low):**` → "Turn back before you reach Greymoor Abbey."
- Ep 3, line 18 (speaker label): `**HOODED RIDER (Defiant):**` → "I am Lord Tobin Vale!"
- Ep 2, line 18 (speaker label): `**TOBIN (Angry):**` → "You owe Rosalind an apology, Tobias."

**Suggested action:** Confirm these labels are one character; if so, pick one speaker label (or approve the alias) so voice and face references stay consistent. (most frequent form: _HOODED RIDER_)

## 2. Worth checking (2)

_Spellings are close, but no line in the scripts links them. They may or may not be the same._

### SG-003 · Possible spelling error · importance: medium · confidence: medium

| Form | Times | Episodes | First seen | In dialogue |
|---|---:|---|---|---:|
| **Rosalind** | 15 | 1–2, 4–6 | ep1:L3 | 6 |
| **Rosalid** | 1 | 2 | ep2:L28 | 1 |

**Why flagged:** 2 spellings share the first 3 letters and are close in spelling (rule G1): Rosalid–Rosalind (similarity 0.875). One form is rare and close to a frequent one (rule G2). No sentence in the scripts links these forms explicitly; the grouping rests on spelling only.

**Evidence:**
- Ep 1, line 3 (continuity note): CONTINUITY NOTES: First episode. Introduces Mara, **Rosalind** and the Hooded Rider.
- Ep 2, line 28 (dialogue, MARA): "I will hear it from **Rosalid** herself."
- Ep 1, line 20 (dialogue, LADY MARA): "**Rosalind**, someone is following us."
- Ep 2, line 20 (dialogue, TOBIN): "You owe **Rosalind** an apology, Tobias."

**Suggested action:** Check whether these refer to the same person/place. If yes, choose the canonical form; if not, mark as different. (most frequent form: _Rosalind_)

### SG-004 · Name variation · importance: medium · confidence: low

| Form | Times | Episodes | First seen | In dialogue |
|---|---:|---|---|---:|
| **Marcel** | 3 | 5 | ep5:L2 | 1 |
| **Marcus** | 3 | 2, 4 | ep2:L39 | 1 |

**Why flagged:** 2 spellings share the first 3 letters and are close in spelling (rule G1): Marcel–Marcus (similarity 0.667). No sentence in the scripts links these forms explicitly; the grouping rests on spelling only.

**Evidence:**
- Ep 5, line 2 (logline): EPISODE LOGLINE: Lord Vale sends a letter with **Marcel**.
- Ep 2, line 39 (action): Lord Greyson rides to Greymoor Abbey with **Marcus** at his side.
- Ep 5, line 16 (dialogue, LORD VALE): "Give the letter to **Marcel** and send it to Rosalind."
- Ep 4, line 28 (dialogue, ROSALIND): "**Marcus**, take the horses."
- Ep 5, line 24 (action): **Marcel** bows to Lord Vale and leaves with the letter for Rosalind.
- Ep 4, line 24 (action): Masked Woman Rosalind lowers her veil beside **Marcus**.

**Suggested action:** Check whether these refer to the same person/place. If yes, choose the canonical form; if not, mark as different. (most frequent form: _Marcus_)

## 3. Needs your judgement (2)

_The evidence points both ways or is too thin to call._

### SG-005 · Possible spelling error · importance: medium · confidence: low

| Form | Times | Episodes | First seen | In dialogue |
|---|---:|---|---|---:|
| **Mara** | 14 | 1–3, 6 | ep1:L2 | 4 |
| **Maira** | 1 | 5 | ep5:L20 | 1 |

**Why flagged:** "Maira" appears 1 time(s); "Mara" appears 14 times and differs by 1 letter(s) (rule G2). "Maira" only ever appears at the start of a sentence or line, so it may be a different name, a nickname or a cover name rather than a typo.

**Evidence:**
- Ep 5, line 20 (dialogue, LADY VALE): "**Maira**, wait! Rosalind is coming."
- Ep 1, line 2 (logline): EPISODE LOGLINE: Lady **Mara** Vellacourt meets the Hooded Rider on the road to Greymoor A…
- Ep 1, line 24 (dialogue, ROSALIND): "Then let them follow, **Mara**."

**Suggested action:** Needs a story decision: the scripts do not show whether these are the same. Check with the writer or the show bible. (most frequent form: _Mara_)

### SG-006 · Same character, different speaker labels · importance: medium · confidence: low

| Form | Times | Episodes | First seen | In dialogue |
|---|---:|---|---|---:|
| **MASKED WOMAN** | 1 | 4 | ep4:L18 | 1 |
| **ROSALIND** | 3 | 1, 4, 6 | ep1:L22 | 3 |

**Why flagged:** B1: 1 line(s) where descriptor followed by name in one phrase ("Rosalind"). G5 timeline: MASKED WOMAN speaks in episode(s) 4; ROSALIND in 1, 4, 6. The label is still used after the name is known, in episode(s) 4. But both labels speak in the same scene (N1: 1 scene(s)), which contradicts the bridge.

**Evidence:**
- Ep 4, line 24 (action): **Masked Woman Rosalind** lowers her veil beside Marcus.
- Ep 4, line 18 (speaker label): `**MASKED WOMAN (Sharp):**` → "She already knows, rider."
- Ep 1, line 22 (speaker label): `**ROSALIND (Calm):**` → "Then let them follow, Mara."

**Suggested action:** Needs a story decision: the scripts do not show whether these are the same. Check with the writer or the show bible. (most frequent form: _ROSALIND_)

## 4. Probably intentional (1)

_Looks like a deliberate choice, such as a title or a description used before a name is revealed._

| ID | Type | Forms | Why |
|---|---|---|---|
| SG-007 | Title variation in speaker labels | LADY MARA (1×; ep 1) | MARA (3×; ep 2–3, 6) | LADY MARA and MARA differ only by a title (rule G3) and never speak in the same scene. They are never used in the same episode, which looks like a per-episode labelling choice. |

## 5. Checked: probably different (2)

_These look alike but the scripts show they are different. Listed so you can confirm._

| ID | Type | Forms | Why |
|---|---|---|---|
| SG-008 | Name variation | Tobin (7×; ep 2–3) | Tobias (6×; ep 2–3) | "Tobias" and "Tobin" look alike (rule G1, similarity 0.667), but were not grouped. N2: "Tobias" and "Tobin" are named separately in the same line (ep2 L2), which suggests two different people. |
| SG-009 | Name variation | Greymoor (5×; ep 1–3) | Greyson (3×; ep 2) | "Greymoor" and "Greyson" look alike (rule G1, similarity 0.625), but were not grouped. N2: "Greymoor" and "Greyson" are named separately in the same line (ep2 L2), which suggests two different entities. |

---
Rules: G1 similar spellings · G2 rare form next to a frequent one · G3 title-only label difference · G4 explicit link between a descriptive label and a name · G5 when the label is used relative to the name reveal · B1–B3 supporting evidence · N1–N2 contradicting evidence. Details: `findings.json`.
