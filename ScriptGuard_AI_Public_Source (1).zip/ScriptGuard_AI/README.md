# ScriptGuard AI

ScriptGuard is a local command-line tool for script editors. It checks a full season of episode screenplays for **characters and places that are referred to inconsistently across episodes**:
- surname or family-name spelling drift
- one-off misspellings of a character's name
- one character speaking under different speaker labels
- place names written in several ways

Every finding cites the exact episode, file, line and text. The editor decides, and the tool never edits a script.

## The problem
AI-assisted microdramas are written and produced episode by episode. In the 50-episode sample show this tool was built on, one central house name appears in several spellings across 19 episodes, and some characters speak under more than one speaker label. Pipelines that attach voice and face references by character name, and translation memories, inherit these inconsistencies. They are hard to spot by reading one episode at a time.

## How it works (no AI model)
ScriptGuard is **deterministic**: parsing, candidate matching and contextual rules. **No LLM is used and none is called**, and screenplay text never leaves the machine. An optional AI verification step was designed but is **not implemented**.

```
ZIP or folder ─► ingest (safe in-memory ZIP read, encoding, episode numbering, missing/duplicate checks)
             ─► parse (scenes, headings, speaker labels, dialogue, action, with exact line numbers)
             ─► extract three separate streams: speaker labels · names in text · scene-heading places
             ─► candidates  G1 similar spellings · G2 rare form beside a frequent one · G3 title-only label difference
                            G4 explicit link between a descriptive label and a name · G5 when the label is used vs the name reveal
             ─► context     B1–B3 supporting evidence · N1 both labels speak in one scene · N2 both forms named on one line
                            (contradicting evidence always wins over spelling similarity)
             ─► findings with confidence (same entity?) and severity (does it matter?) as separate fields
             ─► every quoted line re-read from the original input and checked; any mismatch aborts the report
```
Code: `lib/scriptguard/` (ingest, parser, extract, validate, pipeline) and `lib/scriptguard/detect/` (corpus, candidates, detector, report). Thresholds and word lists live in `config/defaults.json`.

## Requirements
- Ruby 2.6 or newer, standard library only. This is the Ruby that ships with macOS: **nothing to install**.
- `rake` (bundled with Ruby) to run the tests. Optional: the system `zip` command for one test.

## Run
```sh
cd scriptguard
bin/scriptguard scan "/path/to/screenplays.zip" --out runs/pack --expect 1-50
```
That single command parses all episodes, runs detection and writes the reports. A folder of `.txt` episodes also works as input. Other commands:

```sh
bin/scriptguard detect --run runs/pack                                   # re-run detection on an existing parse
bin/scriptguard parse  "/path/to/screenplays.zip" --out runs/pack        # parse and extract only
bin/scriptguard scan   test/fixtures/detect_show --out runs/demo         # invented demo show
```
- `--expect FIRST-LAST`: expected episode range, used to report missing episodes.
- The input is never modified. The output folder may not be inside the input folder.
- Exit codes: `0` ok · `1` input problems reported (missing, duplicate or unreadable episode) · `2` validation failed, input changed, or fatal error.

## Expected input format
One `.txt` file per episode, named like `episode-001-….txt`; the episode number can also come from the header. The template:
```
EPISODE NUMBER: Episode 1
EPISODE LOGLINE: …
CONTINUITY NOTES: …
--- SCRIPT START ---
SCENE 01
Scene heading: INT. VELLACOURT HALL – GREAT HALL – NIGHT
Scene start: 00:00.00
Scene end: 00:40.00
Actions and dialogue:
**CAMERA:**                       (also ACTION, SOUND FX)
Start: (00:00.00) | End: (00:04.00)
Wide shot of the great hall…
**LADY MARA (Breathless):**       speaker label + manner
Start: (00:04.50) | End: (00:07.00)
"Élodie, the lantern is still burning."
--- SCRIPT END ---
```
Other screenplay formats (Fountain, Final Draft, PDF) are **not supported**. They fail loudly with "no scenes / no blocks" errors rather than producing silent partial results.

## Outputs
| File | Contents |
|---|---|
| `report.md` | Plain-language report for an editor, in five sections: check first · worth checking · needs your judgement · probably intentional · checked: probably different |
| `findings.csv` | One row per finding, with columns `review_status` (starts as `pending`), `reviewer_note` and `canonical_form` for the editor's decision |
| `findings.json` | Full findings: candidate forms with counts and episodes, rules fired, assessment, confidence, severity, verified evidence lines with context |
| `entity_inventory.csv` | Every speaker label, name and heading location, with counts, episodes and first appearance |
| `manifest.json`, `episodes.json`, `speaker_labels.jsonl`, `text_mentions.jsonl`, `location_mentions.jsonl`, `token_stats.json`, `issues.json`, `validation.json` | Parse outputs, documented in `docs/data_model.md` |

Example outputs on an invented show: `examples/detect_output/` and `examples/synthetic_output/`.

## Tests
```sh
rake test                                                    # 71 tests on invented fixtures (real-archive tests skip)
SCRIPTGUARD_PACK="/path/to/screenplays.zip" rake test        # + checks on the real archive
```
The real-archive tests contain no screenplay text. They check counts, evidence validity, separation of different entities, and reproducibility.

## Limitations
- **It only confirms explicit links.** A character renamed with no sentence connecting the two labels is not found, and is left for the editor.
- **Some real spelling variants are missed:** forms with similarity below 0.6, or that differ within the first three letters. The sentence-start rule can produce occasional noise from ordinary words.
- **Thresholds were developed and evaluated on one show**, so results are exploratory, not a benchmark.
- **Out of scope:** plot, relationships, time of day, props, voice and appearance. This is not a general continuity checker.
- **Reviewer decisions entered in `findings.csv` are not yet read back by the tool.** Each finding has a stable `fingerprint` for that purpose.

## Confidentiality
Outputs from real scripts contain screenplay text. `runs/`, `*.zip`, `submission/` and the private reports in `docs/` are git-ignored. Only the code, config, invented fixtures and invented example outputs are meant to be shared publicly.
