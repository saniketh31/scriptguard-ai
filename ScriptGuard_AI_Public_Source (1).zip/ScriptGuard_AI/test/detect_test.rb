require_relative 'test_helper'
require 'csv'

# Detection (Session 3) on the invented detect_show fixture. Each scenario is planted deliberately:
#   Rosalind/Rosalid       genuine spelling slip                  -> SPELLING possible
#   Mara/Maira             rare form only at sentence start        -> SPELLING unresolved
#   Greymoor/Greymoore     same abbey, same scene (B3)             -> LOCATION_VARIANT strong
#   Greymoor/Greyson       place vs a lord, named on one line (N2) -> kept apart
#   Tobin/Tobias           brothers who speak in one scene (N1/N2) -> kept apart
#   Marcus/Marcel          different people, never together        -> only "possible" (spelling evidence only)
#   HOODED RIDER = Tobin   "Hooded Rider Tobin" (B1), "I am Lord Tobin Vale!" (B2), used before the reveal
#   MASKED WOMAN = Rosalind? bridged (B1) but both speak in one scene (N1) -> unresolved
#   LADY MARA / MARA       title-only label difference             -> intentional
#   LORD VALE / LADY VALE  different titles = different people     -> no title finding
#   camera words, "Guard Captain", "a weary guard, Tobias", list "the Hooded Rider, Mara, and Tobias" -> nothing
class DetectTest < Minitest::Test
  include TestSupport

  DETECT_SHOW = File.expand_path('fixtures/detect_show', __dir__)

  def self.outcome
    @outcome ||= begin
      dir = Dir.mktmpdir('sg-detect')
      ScriptGuard::Pipeline.new(TestSupport::CONFIG).run(DETECT_SHOW, out_dir: dir)
      [ScriptGuard::Detect.run(dir, TestSupport::CONFIG), dir]
    end
  end

  def setup
    @res, @dir = self.class.outcome
    @f = @res.findings
  end

  def find(*forms)
    want = forms.map(&:downcase).sort
    @f.find { |f| f['candidate_names'].map { |n| n['form'].downcase }.sort == want }
  end

  def test_genuine_spelling_variation_is_possible_not_strong
    f = find('Rosalind', 'Rosalid')
    refute_nil f
    assert_equal 'SPELLING', f['category']
    assert_equal 'possible_spelling_variant', f['assessment']
    assert_includes f['signals']['generators'], 'G2'
  end

  def test_sentence_initial_rare_form_stays_unresolved
    f = find('Mara', 'Maira')
    assert_equal 'unresolved', f['assessment']
    assert_equal 'low', f['confidence_level']
  end

  def test_same_place_in_same_scene_is_strong_location_variant
    f = find('Greymoor', 'Greymoore')
    assert_equal 'LOCATION_VARIANT', f['category']
    assert_equal 'strong_same_entity_candidate', f['assessment']
    assert_equal ['B3'], f['signals']['bridges']
    assert_equal 'co_reference', f['evidence'].first['role']
  end

  def test_similar_place_and_person_are_not_merged
    refute(@f.any? { |f| f['assessment'] != 'likely_different_entities' && f['candidate_names'].map { |n| n['form'] }.include?('Greyson') })
    f = find('Greymoor', 'Greyson')
    assert_equal 'likely_different_entities', f['assessment']
    assert_equal ['N2'], f['signals']['contradictions']
  end

  def test_two_characters_speaking_in_same_scene_are_kept_apart
    f = find('Tobin', 'Tobias')
    assert_equal 'likely_different_entities', f['assessment']
    refute(@f.any? { |x| x['assessment'] != 'likely_different_entities' && (x['candidate_names'].map { |n| n['form'] } & %w[Tobin Tobias]).size == 2 })
  end

  def test_different_people_without_contradiction_are_only_possible
    f = find('Marcus', 'Marcel')
    assert_equal 'possible_spelling_variant', f['assessment']
    assert_equal 'low', f['confidence_level']
  end

  def test_same_character_under_two_speaker_labels
    f = find('HOODED RIDER', 'TOBIN')
    assert_equal 'SPEAKER_LABEL_ALIAS', f['category']
    assert_equal 'strong_same_entity_candidate', f['assessment']
    assert_equal %w[B1 B2], f['signals']['bridges']
    assert_equal [1], f['signals']['pre_reveal_episodes'], 'ep1 use is before the name is revealed'
    assert_equal [3, 4], f['signals']['post_reveal_episodes']
  end

  def test_bridge_contradicted_by_co_presence_is_unresolved
    f = find('MASKED WOMAN', 'ROSALIND')
    assert_equal 'unresolved', f['assessment']
    assert_equal ['N1'], f['signals']['contradictions']
  end

  def test_intentional_title_variation_is_not_an_error
    f = find('LADY MARA', 'MARA')
    assert_equal 'TITLE_VARIANT', f['category']
    assert_equal 'likely_intentional_variation', f['assessment']
    assert_equal 'low', f['severity']
    assert_nil find('LORD VALE', 'LADY VALE'), 'different titles are different people'
  end

  def test_no_false_bridges_from_lists_disguises_or_titles
    aliases = @f.select { |f| f['category'] == 'SPEAKER_LABEL_ALIAS' }.map { |f| f['candidate_names'].map { |n| n['form'] }.sort }
    assert_equal [%w[HOODED\ RIDER TOBIN], %w[MASKED\ WOMAN ROSALIND]].sort, aliases.sort
  end

  def test_camera_and_common_words_never_appear_in_findings
    forms = @f.flat_map { |f| f['candidate_names'].map { |n| n['form'] } }
    %w[Medium Wide Close-up Close Then Brothers Captain].each { |w| refute_includes forms, w }
  end

  def test_confidence_and_severity_are_separate_fields
    @f.each do |f|
      assert_includes %w[high medium low], f['confidence_level']
      assert_includes %w[high medium low], f['severity']
    end
    assert(@f.any? { |f| f['confidence_level'] == 'high' && f['severity'] == 'low' })
  end

  def test_every_finding_has_verified_traceable_evidence
    @f.each do |f|
      refute_empty f['evidence'], f['issue_id']
      %w[issue_id category entity_type candidate_names episode_references line_references evidence explanation
         confidence_level severity suggested_action review_status].each { |k| assert f.key?(k), "#{f['issue_id']} lacks #{k}" }
      assert_equal 'pending', f['review_status']
      f['evidence'].each do |e|
        assert e['verified']
        src = File.read(Dir.glob(File.join(DETECT_SHOW, e['filename'])).first, encoding: 'UTF-8').split("\n")[e['line'] - 1]
        assert_equal src, e['original_text']
        assert_equal e['matched_span'], src[e['col_start']...e['col_end']]
      end
    end
    assert_equal @res.stats['evidence_items'], @res.stats['evidence_verified']
  end

  def test_reports_are_written_and_readable
    %w[findings.json findings.csv report.md entity_inventory.csv].each { |n| assert File.file?(File.join(@dir, n)), n }
    rows = CSV.read(File.join(@dir, 'findings.csv'), headers: true)
    assert_equal @f.size, rows.size
    assert(rows.all? { |r| r['review_status'] == 'pending' })
    md = File.read(File.join(@dir, 'report.md'))
    assert_match(/## 1\. Check first/, md)
    assert_match(/## 5\. Checked: probably different/, md)
    assert_match(/\*\*Greymoore\*\*/, md)
    inv = CSV.read(File.join(@dir, 'entity_inventory.csv'), headers: true)
    assert(inv.any? { |r| r['stream'] == 'speaker_label' && r['form'] == 'HOODED RIDER' })
    assert(inv.any? { |r| r['stream'] == 'heading_location' })
  end

  def test_findings_are_reproducible
    dir = Dir.mktmpdir
    ScriptGuard::Pipeline.new(config).run(DETECT_SHOW, out_dir: dir)
    again = ScriptGuard::Detect.run(dir, config).findings
    strip = ->(fs) { fs.map { |f| f.reject { |k, _| k == 'evidence' }.merge('ev' => f['evidence'].map { |e| [e['filename'], e['line'], e['col_start']] }) } }
    assert_equal strip.(@f), strip.(again)
  end

  def test_wrong_reference_in_parse_output_aborts_the_report
    with_show_copy do |_show, tmp|
      dir = File.join(tmp, 'run')
      ScriptGuard::Pipeline.new(config).run(DETECT_SHOW, out_dir: dir)
      path = File.join(dir, 'text_mentions.jsonl')
      rows = File.readlines(path).map { |l| JSON.parse(l) }
      bad = rows.find { |m| m['name'] == 'Rosalid' }
      bad['col_start'] += 2
      bad['col_end'] += 2
      File.write(path, rows.map { |r| JSON.generate(r) }.join("\n") + "\n")
      e = assert_raises(ScriptGuard::Error) { ScriptGuard::Detect.run(dir, config, out_dir: File.join(tmp, 'rep')) }
      assert_match(/evidence check failed/, e.message)
      refute File.exist?(File.join(tmp, 'rep', 'report.md'))
    end
  end

  def test_changed_input_after_parse_is_refused
    Dir.mktmpdir do |tmp|
      show = File.join(tmp, 'show')
      FileUtils.cp_r(DETECT_SHOW, show)
      run = File.join(tmp, 'run')
      ScriptGuard::Pipeline.new(config).run(show, out_dir: run)
      File.open(Dir.glob(File.join(show, '*.txt')).first, 'a') { |f| f.puts 'edited' }
      e = assert_raises(ScriptGuard::Error) { ScriptGuard::Detect.run(run, config) }
      assert_match(/changed since it was parsed/, e.message)
    end
  end

  def test_session2_synthetic_show_still_detects_family_misspelling
    dir = Dir.mktmpdir
    ScriptGuard::Pipeline.new(config).run(TestSupport::FIXTURE, out_dir: dir)
    f = ScriptGuard::Detect.run(dir, config).findings
    v = f.find { |x| x['candidate_names'].map { |n| n['form'] }.sort == %w[Vellacort Vellacourt] }
    refute_nil v
    refute_equal 'likely_different_entities', v['assessment']
    t = f.find { |x| x['candidate_names'].map { |n| n['form'] }.sort == %w[Tobias Tobin] }
    assert_equal 'likely_different_entities', t['assessment']
  end

  def test_cli_scan_and_detect
    Dir.mktmpdir do |tmp|
      out = StringIO.new
      code = ScriptGuard::CLI.start(['scan', DETECT_SHOW, '--out', File.join(tmp, 's')], out: out, err: StringIO.new)
      assert_equal 0, code
      assert_match(/Detection\s+9 findings: strong 2, possible 2, unresolved 2, intentional 1, rejected by context 2/, out.string)
      assert_match(/30 of 30 evidence lines verified|(\d+) of \1 evidence lines verified/, out.string)
      out2 = StringIO.new
      code = ScriptGuard::CLI.start(['detect', '--run', File.join(tmp, 's'), '--out', File.join(tmp, 'd')], out: out2, err: StringIO.new)
      assert_equal 0, code
      assert File.file?(File.join(tmp, 'd', 'report.md'))
      err = StringIO.new
      assert_equal 2, ScriptGuard::CLI.start(['detect', '--run', File.join(tmp, 'missing')], out: StringIO.new, err: err)
      assert_match(/parse output missing/, err.string)
    end
  end
end
