require_relative '../test_helper'
require 'csv'
require 'digest'

# Runs only when SCRIPTGUARD_PACK points at the confidential input pack. Contains no screenplay text:
# it checks structural counts, validation and read-only behaviour. If SCRIPTGUARD_RESEARCH_DIR points at
# problem3_research/, per-episode counts are compared with 01_dataset_profile.csv (reference, not ground truth).
class PackIntegrationTest < Minitest::Test
  include TestSupport

  def setup
    @zip = ENV['SCRIPTGUARD_PACK']
    skip 'set SCRIPTGUARD_PACK=/path/to/pack.zip to run' unless @zip && File.file?(@zip)
    @@run ||= nil
    @@sha ||= Digest::SHA256.file(@zip).hexdigest
    @@run ||= run_pipeline(@zip, expect: 1..50)
    @run = @@run
  end

  def test_all_fifty_episodes_parsed_without_errors
    assert_equal (1..50).to_a, @run.episodes.map(&:number)
    assert_equal({ 'parsed' => 50 }, @run.summary['episodes']['status'])
    assert_empty @run.summary['episodes']['missing']
    assert_empty @run.summary['episodes']['duplicates']
    assert_equal 0, @run.summary['issues']['errors']
    assert_equal 0, @run.exit_code
  end

  def test_structure_totals
    s = @run.summary
    assert_equal 100, s['structure']['scenes']
    assert_equal 3727, s['structure']['blocks']
    assert_equal 1487, s['stream_a_speaker_labels']['mentions']
    assert_equal 64, s['stream_a_speaker_labels']['distinct_labels']
  end

  def test_every_reference_validates_and_input_unchanged
    assert @run.validation['passed'], @run.validation['failures'].first(5).inspect
    assert @run.summary['input']['unchanged']
    assert_equal @@sha, Digest::SHA256.file(@zip).hexdigest
  end

  def test_speaker_text_lines_are_never_label_or_timing_lines
    @run.streams.speaker_labels.each do |s|
      assert_equal s.label_line + 2, s.text_line, s.id
    end
  end

  def test_per_episode_counts_match_research_profile
    dir = ENV['SCRIPTGUARD_RESEARCH_DIR']
    skip 'set SCRIPTGUARD_RESEARCH_DIR to compare with research' unless dir && File.file?(File.join(dir, '01_dataset_profile.csv'))
    CSV.foreach(File.join(dir, '01_dataset_profile.csv'), headers: true) do |r|
      ep = @run.episodes.find { |e| e.number == r['episode'].to_i }
      assert_equal r['scenes'].to_i, ep.scenes.size, "ep#{r['episode']} scenes"
      assert_equal r['timestamped_events'].to_i, ep.blocks.count(&:timing), "ep#{r['episode']} events"
      assert_equal r['dialogue_lines'].to_i, ep.blocks.count { |b| b.kind == 'DIALOGUE' }, "ep#{r['episode']} dialogue"
      assert_equal r['distinct_speakers'].to_i, ep.blocks.map(&:speaker).compact.uniq.size, "ep#{r['episode']} speakers"
      assert_equal r["line_count"].to_i, ep.line_count, "ep#{r["episode"]} physical lines" if r["line_count"]
    end
  end
end

# Session 3 detection invariants on the real pack (no screenplay text in this file).
class PackDetectionTest < Minitest::Test
  include TestSupport

  def setup
    @zip = ENV['SCRIPTGUARD_PACK']
    skip 'set SCRIPTGUARD_PACK=/path/to/pack.zip to run' unless @zip && File.file?(@zip)
    @@dir ||= Dir.mktmpdir('sg-pack-detect')
    @@res ||= begin
      ScriptGuard::Pipeline.new(config).run(@zip, out_dir: @@dir, expect: 1..50)
      ScriptGuard::Detect.run(@@dir, config)
    end
    @res = @@res
  end

  def test_all_evidence_verified
    assert_operator @res.findings.size, :>, 0
    assert_equal @res.stats['evidence_items'], @res.stats['evidence_verified']
    assert(@res.findings.all? { |f| f['evidence'].all? { |e| e['verified'] } })
  end

  def test_grouped_forms_never_named_separately_on_one_line
    lines = Hash.new { |h, k| h[k] = Set.new }
    File.foreach(File.join(@@dir, 'text_mentions.jsonl')) do |l|
      m = JSON.parse(l)
      m['core_tokens'].each { |t| lines[t.downcase] << [m['filename'], m['line'], m['id']] }
    end
    @res.findings.reject { |f| f['assessment'] == 'likely_different_entities' }.each do |f|
      forms = f['candidate_names'].map { |n| n['normalised'] }.select { |n| lines.key?(n) }
      forms.combination(2).each do |a, b|
        shared = lines[a].map { |x| x[0, 2] } & lines[b].map { |x| x[0, 2] }
        same_mention = shared.all? { |s| (lines[a].select { |x| x[0, 2] == s }.map(&:last) & lines[b].select { |x| x[0, 2] == s }.map(&:last)).any? }
        assert(shared.empty? || same_mention, "#{f['issue_id']} groups #{a}/#{b} named separately on one line")
      end
    end
  end

  def test_title_variants_are_never_reported_as_errors
    @res.findings.select { |f| f['category'] == 'TITLE_VARIANT' }.each do |f|
      assert_includes %w[likely_intentional_variation likely_different_entities], f['assessment']
      assert_equal 'low', f['severity']
    end
  end

  def test_headline_structures_exist
    assert(@res.findings.any? { |f| f['category'] == 'NAME_VARIANT' && f['assessment'] == 'strong_same_entity_candidate' && f['candidate_names'].size >= 5 })
    assert(@res.findings.any? { |f| f['category'] == 'SPEAKER_LABEL_ALIAS' && f['assessment'] == 'strong_same_entity_candidate' && (f['signals']['bridges'] & %w[B1 B2]).size == 2 })
    assert_equal 0, @res.findings.count { |f| f['assessment'] == 'strong_same_entity_candidate' && f['confidence_level'] != 'high' }
  end

  def test_detection_is_reproducible
    again = ScriptGuard::Detect.run(@@dir, config, out_dir: Dir.mktmpdir).findings
    assert_equal @res.findings.map { |f| [f['fingerprint'], f['assessment'], f['line_references']] },
                 again.map { |f| [f['fingerprint'], f['assessment'], f['line_references']] }
  end
end
