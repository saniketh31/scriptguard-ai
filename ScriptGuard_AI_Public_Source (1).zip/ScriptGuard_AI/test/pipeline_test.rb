require_relative 'test_helper'

class PipelineTest < Minitest::Test
  include TestSupport

  def test_outputs_are_written_and_parseable
    Dir.mktmpdir do |tmp|
      out = File.join(tmp, 'out')
      run = run_pipeline(TestSupport::FIXTURE, out: out)
      %w[manifest.json issues.json episodes.json token_stats.json validation.json].each do |f|
        assert JSON.parse(File.read(File.join(out, f))), f
      end
      %w[speaker_labels.jsonl text_mentions.jsonl location_mentions.jsonl].each do |f|
        rows = File.readlines(File.join(out, f)).map { |l| JSON.parse(l) }
        refute_empty rows, f
      end
      m = JSON.parse(File.read(File.join(out, 'manifest.json')))
      assert_equal true, m['input']['unchanged']
      assert_equal 4, m['sources'].size
      refute m['sources'].first.key?('lines'), 'manifest must not embed full source text'
      assert_equal run.streams.text_mentions.size, File.readlines(File.join(out, 'text_mentions.jsonl')).size
    end
  end

  def test_output_inside_input_is_refused
    with_show_copy do |show|
      assert_raises(ScriptGuard::Error) { run_pipeline(show, out: File.join(show, 'out')) }
      assert_raises(ScriptGuard::Error) { run_pipeline(show, out: show) }
    end
  end

  def test_input_directory_unchanged_after_run
    with_show_copy do |show, tmp|
      snap = -> { Dir.glob(File.join(show, '**/*')).sort.map { |f| [f, File.binread(f), File.mtime(f)] } }
      before = snap.call
      run_pipeline(show, out: File.join(tmp, 'out'))
      assert_equal before, snap.call
    end
  end

  def test_validator_detects_a_wrong_reference
    run = run_pipeline(TestSupport::FIXTURE)
    ing = ScriptGuard::Ingest.new(config).call(TestSupport::FIXTURE)
    %w[ep001 ep002 ep003 ep004].zip(ing.sources).each { |k, s| s.key = k }
    m = run.streams.text_mentions.find { |x| x.name == 'Tobias' }
    m.col_start += 1
    m.col_end += 1
    res = ScriptGuard::Validator.new(config).call(ing, run.episodes, run.streams)
    refute res['passed']
    assert(res['failures'].any? { |f| f.include?(m.id) })
  end

  def test_structure_counts_cross_checked_against_raw_lines
    run = run_pipeline(TestSupport::FIXTURE)
    checks = run.validation['checks']
    assert_equal 4, checks['count_timing_lines']
    assert_equal 4, checks['count_scene_markers']
    assert run.validation['passed']
  end
end
