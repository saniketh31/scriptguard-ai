require_relative 'test_helper'

class CLITest < Minitest::Test
  include TestSupport

  def cli(*args)
    out = StringIO.new
    err = StringIO.new
    code = ScriptGuard::CLI.start(args, out: out, err: err)
    [code, out.string, err.string]
  end

  def test_parse_prints_summary_and_returns_zero
    Dir.mktmpdir do |tmp|
      code, out, = cli('parse', TestSupport::FIXTURE, '--out', File.join(tmp, 'o'), '--expect', '1-4')
      assert_equal 0, code
      assert_match(/Episodes\s+discovered 4, expected range 1-4/, out)
      assert_match(/missing none; duplicates none/, out)
      assert_match(/Structure\s+scenes 5, blocks 16/, out)
      assert_match(/Stream A\s+speaker-label mentions 10, distinct labels 6/, out)
      assert_match(/Stream C\s+location mentions 10/, out)
      assert_match(/Validation\s+PASSED/, out)
    end
  end

  def test_missing_episode_exit_code_one
    with_show_copy do |show, tmp|
      File.delete(Dir.glob(File.join(show, 'episode-004-*.txt')).first)
      code, out, = cli('parse', show, '--out', File.join(tmp, 'o'), '--expect', '1-4')
      assert_equal 1, code
      assert_match(/missing 4/, out)
      assert_match(/ERROR missing_episode/, out)
    end
  end

  def test_usage_errors
    code, _, err = cli('parse', TestSupport::FIXTURE)
    assert_equal 2, code
    assert_match(/Usage/, err)
    code, _, err = cli('parse', '/nonexistent/path', '--out', '/tmp/x-sg')
    assert_equal 2, code
    assert_match(/input not found/, err)
    code, out, = cli('--help')
    assert_equal 0, code
    assert_match(/Usage/, out)
    code, _, err = cli('parse', TestSupport::FIXTURE, '--out', '/tmp/x', '--expect', 'abc')
    assert_equal 2, code
    assert_match(/invalid argument/, err)
  end
end
