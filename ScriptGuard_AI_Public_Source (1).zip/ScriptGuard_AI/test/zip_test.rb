require_relative 'test_helper'

class ZipTest < Minitest::Test
  include TestSupport

  def test_stored_and_deflated_zip_match_directory_results
    dir_run = run_pipeline(TestSupport::FIXTURE)
    Dir.mktmpdir do |tmp|
      [0, 8].each do |method|
        zip = write_zip(File.join(tmp, "show#{method}.zip"), show_entries(method: method))
        run = run_pipeline(zip)
        assert_equal 'zip', run.summary['input']['kind']
        assert_equal dir_run.streams.text_mentions.map { |m| [m.id, m.surface] }, run.streams.text_mentions.map { |m| [m.id, m.surface] }
        assert_equal dir_run.streams.location_mentions.map(&:id), run.streams.location_mentions.map(&:id)
        assert run.validation['passed'], run.validation['failures'].inspect
        assert run.summary['input']['unchanged']
      end
    end
  end

  def test_real_zip_tool_archive_is_readable
    skip 'zip command not available' unless system('which zip > /dev/null 2>&1')
    Dir.mktmpdir do |tmp|
      FileUtils.cp_r(TestSupport::FIXTURE, File.join(tmp, 'Synthetic Show'))
      zip = File.join(tmp, 'pack.zip')
      Dir.chdir(tmp) { system('zip', '-qr', zip, 'Synthetic Show') }
      run = run_pipeline(zip)
      assert_equal [1, 2, 3, 4], run.episodes.map(&:number)
      assert_equal 0, run.exit_code
    end
  end

  def test_path_traversal_absolute_and_symlink_entries_are_refused_and_never_written
    Dir.mktmpdir do |tmp|
      work = File.join(tmp, 'work')
      FileUtils.mkdir_p(work)
      evil = [
        { name: '../evil-episode-007.txt', data: File.read(fixture_file(1)) },
        { name: '/tmp/abs-episode-008.txt', data: File.read(fixture_file(1)) },
        { name: 'show/..\\..\\win-episode-009.txt', data: 'x' },
        { name: 'show/episode-010-link.txt', data: '/etc/passwd', symlink: true }
      ]
      zip = write_zip(File.join(work, 'evil.zip'), show_entries + evil)
      run = run_pipeline(zip, out: File.join(tmp, 'out'))
      unsafe = run.issues.select { |i| i.code == 'unsafe_archive_entry' }
      assert_equal 4, unsafe.size, unsafe.map(&:message).inspect
      assert_match(/path traversal/, unsafe.find { |i| i.file.start_with?('../') }.message)
      assert_match(/absolute path/, unsafe.find { |i| i.file.start_with?('/tmp') }.message)
      assert_match(/symbolic link/, unsafe.find { |i| i.file.end_with?('link.txt') }.message)
      assert_equal [1, 2, 3, 4], run.episodes.map(&:number)
      refute File.exist?(File.join(tmp, 'evil-episode-007.txt'))
      refute File.exist?('/tmp/abs-episode-008.txt')
      assert_equal 1, run.exit_code
    end
  end

  def test_crc_corruption_is_reported_as_unreadable
    Dir.mktmpdir do |tmp|
      entries = show_entries
      entries[1][:crc] = 12_345
      zip = write_zip(File.join(tmp, 'bad.zip'), entries)
      run = run_pipeline(zip)
      err = run.issues.find { |i| i.code == 'unreadable_file' }
      refute_nil err
      assert_match(/CRC mismatch/, err.message)
      assert_equal [1, 3, 4], run.episodes.map(&:number)
      assert_includes run.summary['episodes']['missing'], 2
    end
  end

  def test_not_a_zip_raises_clear_error
    Dir.mktmpdir do |tmp|
      f = File.join(tmp, 'fake.zip')
      File.write(f, 'this is not a zip')
      e = assert_raises(ScriptGuard::Error) { run_pipeline(f) }
      assert_match(/not a ZIP/, e.message)
    end
  end

  def test_oversized_entry_is_refused
    Dir.mktmpdir do |tmp|
      zip = write_zip(File.join(tmp, 'big.zip'), [{ name: 'episode-001.txt', data: 'a' * 2000 }])
      cfg = JSON.parse(JSON.generate(config))
      cfg['limits']['max_entry_bytes'] = 1000
      run = ScriptGuard::Pipeline.new(cfg).run(zip)
      assert_match(/above limit/, run.issues.find { |i| i.code == 'unsafe_archive_entry' }.message)
    end
  end

  def test_input_zip_is_not_modified
    Dir.mktmpdir do |tmp|
      zip = write_zip(File.join(tmp, 'show.zip'), show_entries(method: 8))
      before = [File.binread(zip), File.mtime(zip)]
      run_pipeline(zip, out: File.join(tmp, 'out'))
      assert_equal before, [File.binread(zip), File.mtime(zip)]
    end
  end
end
