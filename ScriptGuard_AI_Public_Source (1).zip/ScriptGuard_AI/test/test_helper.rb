$LOAD_PATH.unshift File.expand_path('../lib', __dir__)
require 'minitest/autorun'
require 'tmpdir'
require 'fileutils'
require 'json'
require 'stringio'
require 'zlib'
require 'scriptguard'

module TestSupport
  FIXTURE = File.expand_path('fixtures/synthetic_show', __dir__)
  CONFIG = ScriptGuard::Pipeline.load_config

  def config
    CONFIG
  end

  # Copies the synthetic show into a fresh temp dir; yields the dir path.
  def with_show_copy
    Dir.mktmpdir('sg-test') do |tmp|
      show = File.join(tmp, 'show')
      FileUtils.cp_r(FIXTURE, show)
      yield show, tmp
    end
  end

  def fixture_file(n)
    Dir.glob(File.join(FIXTURE, format('episode-%03d-*.txt', n))).first
  end

  def run_pipeline(input, out: nil, expect: nil)
    ScriptGuard::Pipeline.new(config).run(input, out_dir: out, expect: expect)
  end

  def issue_codes(run_or_issues)
    issues = run_or_issues.respond_to?(:issues) ? run_or_issues.issues : run_or_issues
    issues.map(&:code)
  end

  # Builds a source from in-memory text and parses it (no pipeline).
  def parse_text(text, episode: 1, path: 'episode-001-test.txt')
    lines, info = ScriptGuard::Ingest.decode_bytes(text.b)
    src = ScriptGuard::SourceFile.new(key: format('ep%03d', episode), path: path, filename: File.basename(path),
                                      lines: lines, episode_number: episode, duplicate: false, encoding: info['encoding'])
    ScriptGuard::Parser.new(config).parse(src)
  end

  # Minimal ZIP writer for tests. entries: [{name:, data:, method: 0|8, symlink: bool, crc: override}]
  def write_zip(path, entries)
    out = ''.b
    central = ''.b
    entries.each do |e|
      name = e[:name].b
      data = e[:data].b
      method = e[:method] || 0
      payload = method == 8 ? deflate_raw(data) : data
      crc = e[:crc] || Zlib.crc32(data)
      offset = out.bytesize
      out << [0x04034b50, 20, 0, method, 0, 0, crc, payload.bytesize, data.bytesize, name.bytesize, 0].pack('VvvvvvVVVvv')
      out << name << payload
      mode = e[:symlink] ? 0o120777 : 0o100644
      central << [0x02014b50, (3 << 8) | 20, 20, 0, method, 0, 0, crc, payload.bytesize, data.bytesize,
                  name.bytesize, 0, 0, 0, 0, mode << 16, offset].pack('VvvvvvvVVVvvvvvVV')
      central << name
    end
    cd_off = out.bytesize
    out << central
    out << [0x06054b50, 0, 0, entries.size, entries.size, central.bytesize, cd_off, 0].pack('VvvvvVVv')
    File.binwrite(path, out)
    path
  end

  def deflate_raw(data)
    z = Zlib::Deflate.new(Zlib::DEFAULT_COMPRESSION, -Zlib::MAX_WBITS)
    s = z.deflate(data, Zlib::FINISH)
    z.close
    s
  end

  def show_entries(prefix = 'Synthetic Show/', method: 0)
    Dir.glob(File.join(FIXTURE, '*.txt')).sort.map do |f|
      { name: prefix + File.basename(f), data: File.binread(f), method: method }
    end
  end
end
