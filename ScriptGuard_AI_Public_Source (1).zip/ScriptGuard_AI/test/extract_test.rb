require_relative 'test_helper'

class ExtractTest < Minitest::Test
  include TestSupport

  def setup
    @run ||= run_pipeline(TestSupport::FIXTURE)
    @tm = @run.streams.text_mentions
    @sl = @run.streams.speaker_labels
    @lm = @run.streams.location_mentions
  end

  def source_line(ep, line)
    File.read(fixture_file(ep), encoding: 'UTF-8').split("\n")[line - 1]
  end

  # --- Stream A ---------------------------------------------------------------
  def test_speaker_labels_are_their_own_stream_with_exact_lines
    assert_equal 10, @sl.size
    l = @sl.find { |s| s.speaker == 'ÉLODIE' }
    assert_equal 'ep001-L00022-SPK', l.id
    assert_equal '**' + l.label_raw + '**', source_line(1, l.label_line)
    assert_equal 24, l.text_line
    assert_equal ['Off-screen', 'Calm, Certain'], l.parentheticals
  end

  def test_similar_speaker_labels_are_never_merged
    labels = @sl.map(&:speaker).uniq.sort
    assert_equal ['HOODED RIDER', 'LADY MARA', 'MARA', 'TOBIAS', 'TOBIN', 'ÉLODIE'], labels
    # Tobin and Tobias speak in the same scene: two different labels, two different blocks
    scene = @sl.select { |s| s.episode == 2 && s.scene_number == 1 }.map(&:speaker)
    assert_includes scene, 'TOBIN'
    assert_includes scene, 'TOBIAS'
  end

  # --- Stream B ---------------------------------------------------------------
  def test_every_text_mention_slices_back_to_its_source
    @tm.each do |m|
      assert_equal m.surface, source_line(m.episode, m.line)[m.col_start...m.col_end], m.id
      assert_equal m.original_text, source_line(m.episode, m.line), m.id
    end
  end

  def test_similar_names_stay_separate_mentions
    tobin = @tm.select { |m| m.core_tokens.include?('Tobin') }
    tobias = @tm.select { |m| m.core_tokens.include?('Tobias') }
    refute_empty tobin
    refute_empty tobias
    assert_empty tobin & tobias
    # same line, two separate mentions
    line16 = @tm.select { |m| m.episode == 2 && m.line == 16 }.map(&:name)
    assert_equal %w[Medium Tobin Tobias], line16
  end

  def test_titles_possessives_connectors_and_unicode
    duke = @tm.find { |m| m.name == 'Duke of Vellacourt' }
    assert_equal ['Duke'], duke.titles
    assert_equal ['Vellacourt'], duke.core_tokens
    poss = @tm.find { |m| m.surface == "Mara's" }
    assert poss.possessive
    assert_equal 'Mara', poss.name
    elodie = @tm.select { |m| m.name == 'Élodie' }
    assert_equal 4, elodie.size
    curly = elodie.find { |m| m.line == 20 && m.episode == 1 }
    assert_equal 1, curly.col_start, 'curly opening quote must not shift the column'
    assert curly.sentence_initial
  end

  def test_variant_spelling_is_extracted_verbatim_not_normalised
    forms = @tm.flat_map(&:core_tokens).uniq
    assert_includes forms, 'Vellacourt'
    assert_includes forms, 'Vellacort'
  end

  def test_closed_class_words_and_contractions_are_not_mentions
    names = @tm.map(&:name)
    %w[I'm The I It].each { |w| refute_includes names, w }
  end

  def test_sentence_initial_verb_is_split_from_name
    imagine = @tm.find { |m| m.name == 'Imagine' }
    assert imagine.split_at_sentence_start
    el = @tm.find { |m| m.episode == 1 && m.line == 48 && m.name == 'Élodie' }
    refute_nil el
    refute el.sentence_initial
  end

  def test_false_negative_risk_names_are_kept_and_flagged
    # "Wren" only ever appears at sentence start; "Hope" is also an ordinary word.
    wren = @tm.select { |m| m.name == 'Wren' }
    assert_equal 2, wren.size
    assert wren.all? { |m| m.name_evidence == 'capitalised_only_at_sentence_start' }
    hope = @tm.find { |m| m.name == 'Hope' }
    assert_equal 'common_word', hope.name_evidence
  end

  def test_descriptor_and_name_bridge_span_is_preserved_for_session3
    bridge = @tm.find { |m| m.name == 'Hooded Rider Tobin' }
    refute_nil bridge
    self_id = @tm.find { |m| m.name == 'Lord Tobin Vale' }
    assert_equal 'HOODED RIDER', self_id.speaker
    assert_equal 'dialogue', self_id.source_kind
  end

  def test_header_mentions_have_correct_columns
    m = @tm.find { |x| x.source_kind == 'logline' && x.name == 'Vellacourt Hall' && x.episode == 1 }
    assert_equal 'EPISODE LOGLINE: ', source_line(1, 2)[0, 17]
    assert_equal 'Vellacourt Hall', source_line(1, 2)[m.col_start...m.col_end]
  end

  # --- Stream C ---------------------------------------------------------------
  def test_location_segments_from_headings_only
    segs = @lm.map { |l| [l.episode, l.segment, l.role] }
    assert_includes segs, [1, 'VELLACOURT HALL', 'primary']
    assert_includes segs, [1, 'GREAT HALL', 'sub']
    assert_includes segs, [3, 'COTTAGE', 'alternative']
    assert @lm.all? { |l| source_line(l.episode, l.line)[l.col_start...l.col_end] == l.segment }
  end

  def test_not_every_capitalised_heading_word_is_a_name
    great = @lm.find { |l| l.segment == 'GREAT HALL' }
    assert_equal 'generic_only', great.name_evidence
    assert_empty great.non_generic_tokens
    hall = @lm.find { |l| l.segment == 'VELLACOURT HALL' }
    assert_equal ['VELLACOURT'], hall.non_generic_tokens
    assert_equal 'proper_noun_in_text', hall.name_evidence
    study = @lm.find { |l| l.segment == "TOBIN'S STUDY" }
    assert_equal "TOBIN'S", study.possessive_owner
    assert_empty study.non_generic_tokens
  end

  def test_alternative_segment_keeps_its_own_int_ext
    alt = @lm.find { |l| l.episode == 3 && l.role == 'alternative' }
    assert_equal 'EXT.', alt.int_ext
    assert_equal 'COTTAGE', alt.segment
  end

  def test_time_of_day_is_not_a_location
    refute(@lm.any? { |l| %w[NIGHT DAY PRE-DAWN DUSK CONTINUOUS].include?(l.segment) })
  end
end
