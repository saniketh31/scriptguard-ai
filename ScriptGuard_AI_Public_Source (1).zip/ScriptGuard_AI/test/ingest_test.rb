require_relative 'test_helper'

class IngestTest < Minitest::Test
  include TestSupport

  def test_directory_discovers_and_identifies_all_episodes
    run = run_pipeline(TestSupport::FIXTURE)
    assert_equal [1, 2, 3, 4], run.episodes.map(&:number)
    assert_equal %w[ep001 ep002 ep003 ep004], run.episodes.map(&:key)
    assert_empty run.issues.select { |i| i.severity == 'error' }
    assert_equal 0, run.exit_code
  end

  def test_missing_episode_is_reported
    with_show_copy do |show|
      File.delete(Dir.glob(File.join(show, 'episode-002-*.txt')).first)
      run = run_pipeline(show, expect: 1..4)
      assert_equal [2], run.summary['episodes']['missing']
      assert_includes issue_codes(run), 'missing_episode'
      assert_equal 1, run.exit_code
    end
  end

  def test_missing_episode_detected_without_expect_when_gap_inside_range
    with_show_copy do |show|
      File.delete(Dir.glob(File.join(show, 'episode-003-*.txt')).first)
      run = run_pipeline(show)
      assert_equal [3], run.summary['episodes']['missing']
    end
  end

  def test_duplicate_episode_is_reported_and_both_files_kept
    with_show_copy do |show|
      FileUtils.cp(Dir.glob(File.join(show, 'episode-001-*.txt')).first, File.join(show, 'episode-001-copy.txt'))
      run = run_pipeline(show)
      assert_equal [1], run.summary['episodes']['duplicates']
      assert_includes issue_codes(run), 'duplicate_episode'
      dup = run.episodes.select { |e| e.number == 1 }
      assert_equal 2, dup.size
      assert_equal %w[ep001-f1 ep001-f2], dup.map(&:key).sort
      assert dup.all?(&:duplicate)
      assert run.validation['passed'], run.validation['failures'].inspect
    end
  end

  def test_unsupported_and_system_files
    with_show_copy do |show|
      File.write(File.join(show, 'notes.pdf'), '%PDF-1.4')
      File.write(File.join(show, '.DS_Store'), 'x')
      FileUtils.mkdir_p(File.join(show, '__MACOSX'))
      File.write(File.join(show, '__MACOSX', '._episode-001.txt'), 'junk')
      run = run_pipeline(show)
      assert_includes issue_codes(run), 'unsupported_file'
      assert_equal 2, run.summary['files']['skipped_system_files']
      assert_equal 4, run.episodes.size
    end
  end

  def test_empty_and_binary_files_are_errors_not_silently_dropped
    with_show_copy do |show|
      File.write(File.join(show, 'episode-005-empty.txt'), '')
      File.binwrite(File.join(show, 'episode-006-binary.txt'), "\x00\x01\x02binary".b)
      run = run_pipeline(show)
      codes = issue_codes(run)
      assert_includes codes, 'empty_file'
      assert_includes codes, 'binary_file'
      assert_equal 1, run.exit_code
    end
  end

  def test_unidentified_episode_is_an_error
    with_show_copy do |show|
      File.write(File.join(show, 'random-notes.txt'), "Just notes\nNo header\n")
      run = run_pipeline(show)
      assert_includes issue_codes(run), 'unidentified_episode'
      assert_equal 4, run.episodes.size
    end
  end

  def test_episode_number_from_header_when_filename_has_none
    with_show_copy do |show|
      File.rename(Dir.glob(File.join(show, 'episode-004-*.txt')).first, File.join(show, 'finale.txt'))
      run = run_pipeline(show)
      assert_equal [1, 2, 3, 4], run.episodes.map(&:number)
      assert_includes issue_codes(run), 'episode_from_header'
    end
  end

  def test_filename_header_mismatch_warns
    with_show_copy do |show|
      File.rename(Dir.glob(File.join(show, 'episode-004-*.txt')).first, File.join(show, 'episode-005-x.txt'))
      run = run_pipeline(show)
      assert_includes issue_codes(run), 'episode_number_mismatch'
    end
  end

  def test_invalid_utf8_is_reported_with_line_and_numbering_preserved
    with_show_copy do |show|
      f = Dir.glob(File.join(show, 'episode-004-*.txt')).first
      lines = File.binread(f).split("\n", -1)
      lines[19] = "\"Goodbye, Vell\xFFacourt.\"".b
      File.binwrite(f, lines.join("\n"))
      run = run_pipeline(show)
      inv = run.issues.find { |i| i.code == 'invalid_utf8' }
      refute_nil inv
      assert_equal 20, inv.line
      ep = run.episodes.find { |e| e.number == 4 }
      blk = ep.blocks.find { |b| b.speaker == 'MARA' }
      assert_equal 20, blk.text_line
      assert_includes blk.body.first.text, "�"
      assert run.validation['passed'], run.validation['failures'].inspect
    end
  end

  def test_bom_and_utf16_are_decoded
    lines, info = ScriptGuard::Ingest.decode_bytes("\xEF\xBB\xBFEPISODE NUMBER: Episode 1\nÉlodie".b)
    assert_equal 'UTF-8', info['bom']
    assert_equal ['EPISODE NUMBER: Episode 1', 'Élodie'], lines
    utf16 = "\xFF\xFE".b + "SCENE 01\nÉlodie".encode('UTF-16LE').b
    lines, info = ScriptGuard::Ingest.decode_bytes(utf16)
    assert_equal 'UTF-16LE', info['transcoded_from']
    assert_equal ['SCENE 01', 'Élodie'], lines
  end

  def test_crlf_and_lf_give_identical_structure_and_line_numbers
    with_show_copy do |show, tmp|
      crlf = File.join(tmp, 'crlf')
      FileUtils.mkdir_p(crlf)
      Dir.glob(File.join(show, '*.txt')).each do |f|
        File.binwrite(File.join(crlf, File.basename(f)), File.binread(f).gsub("\n", "\r\n"))
      end
      a = run_pipeline(show)
      b = run_pipeline(crlf)
      assert_equal a.streams.text_mentions.map { |m| [m.id, m.surface] }, b.streams.text_mentions.map { |m| [m.id, m.surface] }
      assert_equal a.streams.speaker_labels.map(&:id), b.streams.speaker_labels.map(&:id)
      src_endings = ScriptGuard::Ingest.new(config).call(crlf).sources.map(&:line_ending).uniq
      assert_equal ['CRLF'], src_endings
      assert b.validation['passed']
    end
  end

  def test_mixed_line_endings_warn
    with_show_copy do |show|
      f = Dir.glob(File.join(show, 'episode-004-*.txt')).first
      data = File.binread(f)
      File.binwrite(f, data.sub("\n", "\r\n"))
      run = run_pipeline(show)
      assert_includes issue_codes(run), 'line_endings'
    end
  end

  def test_symlinks_in_directory_are_not_followed
    with_show_copy do |show, tmp|
      outside = File.join(tmp, 'secret.txt')
      File.write(outside, 'EPISODE NUMBER: Episode 9')
      File.symlink(outside, File.join(show, 'episode-009-link.txt'))
      run = run_pipeline(show)
      assert_includes issue_codes(run), 'symlink_skipped'
      refute_includes run.episodes.map(&:number), 9
    end
  end
end
