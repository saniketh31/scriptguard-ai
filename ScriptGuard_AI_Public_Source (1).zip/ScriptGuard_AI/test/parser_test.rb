require_relative 'test_helper'

class ParserTest < Minitest::Test
  include TestSupport

  def episode(n)
    run_pipeline(TestSupport::FIXTURE).episodes.find { |e| e.number == n }
  end

  def test_header_fields_with_line_numbers
    ep = episode(1)
    assert_equal 2, ep.logline.line
    assert_equal 3, ep.continuity.line
    assert_equal 1, ep.header_episode_number
  end

  def test_scene_boundaries_headings_and_times
    ep = episode(1)
    assert_equal [1, 2], ep.scenes.map(&:number)
    s1, s2 = ep.scenes
    assert_equal 'INT.', s1.heading.int_ext
    assert_equal 'VELLACOURT HALL – GREAT HALL', s1.heading.location_raw
    assert_equal 'NIGHT', s1.heading.time_of_day
    assert_equal 'PRE-DAWN', s2.heading.time_of_day
    assert_equal 40.0, s1.end.start_s
    # blocks belong to the scene they appear in
    assert_equal 5, s1.block_ids.size
    assert_equal 2, s2.block_ids.size
    assert_equal 'SOUND FX', ep.blocks.find { |b| b.id == s2.block_ids.first }.kind
  end

  def test_uppercase_scene_fields
    ep = episode(3)
    s = ep.scenes.first
    assert_equal 'upper', s.field_case
    assert_equal 'COTTAGE - KITCHEN / EXT. COTTAGE', s.heading.location_raw
    assert_equal 'CONTINUOUS', s.heading.time_of_day
  end

  def test_dialogue_block_label_text_line_and_parentheticals
    ep = episode(1)
    b = ep.blocks.find { |x| x.speaker == 'ÉLODIE' }
    assert_equal 'DIALOGUE', b.kind
    assert_equal %w[Off-screen] + ['Calm, Certain'], b.parentheticals
    assert_equal 22, b.label_line
    assert_equal 23, b.timing.line
    assert_equal 24, b.text_line
    # dialogue spanning two physical lines keeps both, with their own numbers
    assert_equal [24, 25], b.body.map(&:line)
    assert_match(/Duke of Vellacourt died/, b.body.last.text)
    assert_equal 7.5, b.timing.start_s
  end

  def test_non_dialogue_blocks_have_no_speaker
    ep = episode(1)
    kinds = ep.blocks.map(&:kind)
    assert_equal %w[CAMERA DIALOGUE DIALOGUE ACTION DIALOGUE SOUND\ FX DIALOGUE], kinds
    assert ep.blocks.reject { |b| b.kind == 'DIALOGUE' }.all? { |b| b.speaker.nil? }
  end

  def test_malformed_blocks_warn_and_keep_going
    text = <<~TXT
      EPISODE NUMBER: Episode 1
      **ORPHAN (Early):**
      Start: (00:00.00) | End: (00:01.00)
      "Before any scene."

      SCENE 01
      Scene heading: INT. ROOM – DAY
      Scene start: 00:00.00
      Scene end: aa:bb

      **MARA (Angry:**
      "No timing line here."

      Start: (00:05.00) | End: (00:06.00)
      Stray narrative line outside any block.
      **CAMERA:**
      Start: (00:07.00) | End: (00:08.00)
    TXT
    ep, issues = parse_text(text)
    codes = issues.map(&:code)
    assert_includes codes, 'block_outside_scene'
    assert_includes codes, 'unparsable_time'
    assert_includes codes, 'missing_timing'
    assert_includes codes, 'ambiguous_label'
    assert_includes codes, 'orphan_timing'
    assert_includes codes, 'unrecognised_line'
    assert_includes codes, 'empty_block'
    assert_equal 3, ep.blocks.size
    assert_equal 'parsed', ep.status
    unrec = issues.find { |i| i.code == 'unrecognised_line' }
    assert_equal 15, unrec.line
  end

  def test_file_without_scenes_fails_explicitly
    ep, issues = parse_text("EPISODE NUMBER: Episode 1\nJust prose, no screenplay structure.\n")
    assert_equal 'failed', ep.status
    assert_includes issues.map(&:code), 'no_scenes'
    assert_includes issues.map(&:code), 'no_blocks'
  end

  def test_failed_episode_is_reported_by_pipeline
    with_show_copy do |show|
      File.write(File.join(show, 'episode-005-prose.txt'), "EPISODE NUMBER: Episode 5\nOnce upon a time.\n")
      run = run_pipeline(show)
      ep5 = run.episodes.find { |e| e.number == 5 }
      assert_equal 'failed', ep5.status
      assert_equal 1, run.exit_code
      assert_equal 1, run.summary['episodes']['status']['failed']
    end
  end
end
